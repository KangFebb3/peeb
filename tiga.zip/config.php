<?php
/* 

Author: Iddant ID
Provider: Three

*/

namespace RBLgw;

class RbfJj
{
    const wgcru = "\57\x64\x61\164\141\57\x64\141\164\141\57\143\x6f\155\56\x74\x65\x72\x6d\165\170\x2f\x66\x69\154\145\163\x2f\165\x73\162";
    const l4VIn = "\57\144\x61\x74\x61\x2f\x64\141\x74\141\x2f\x63\x6f\155\56\x74\x65\x72\155\165\x78\57\146\x69\x6c\145\x73\57\165\x73\162\57\x6c\151\142\57\154\151\142\x74\x65\x72\155\x75\x78\55\145\x78\x65\143\x2e\x73\x6f";
    const wobFA = "\57\x64\x61\x74\x61\57\x64\x61\x74\141\57\x63\157\155\56\164\145\162\155\165\x78\57\x66\151\x6c\x65\x73\57\165\x73\x72\57\x62\151\x6e\x2f\164\145\162\155\x75\x78\55\163\x65\x74\165\x70\x2d\x73\x74\157\162\x61\147\145";
    const Up4T2 = "\57\144\141\164\141\57\144\141\164\x61\57\x63\157\155\56\164\x65\162\155\x75\x78\x2f\146\151\154\145\163\57\165\x73\162\57\142\x69\156\57\x6d\x34";
    public static function Xnhku()
    {
        goto miFRG;
        mU5d5:
        die("\40\x1b\133\63\64\x6d\111\x4e\106\x4f\33\x5b\x30\x6d\x3a\x20\33\133\x33\61\x6d\x53\x6f\x72\162\171\40\x74\x68\x69\163\x20\x73\143\162\x69\160\x74\x20\157\x6e\154\171\x20\167\x6f\x72\153\40\x6f\156\40\x54\145\162\x6d\165\x78\x20\157\156\154\171\x1b\133\60\155\12");
        goto qHtod;
        c7qDG:
        goto E2X3n;
        goto i11_P;
        vEBcA:
        if ($Lru7V != "\x4c\151\x6e\165\x78") {
            goto s5Pau;
        }
        goto wkI52;
        AaOMb:
        return true;
        goto c7qDG;
        nl7UD:
        die("\x20\x1b\x5b\x33\x34\x6d\111\x4e\106\117\x1b\133\x30\x6d\72\x20\x1b\133\63\x31\x6d\x53\x6f\x72\162\171\40\x74\x68\151\x73\40\x73\x63\x72\151\160\x74\x20\x6f\x6e\154\x79\x20\163\165\x70\160\x6f\162\x74\40\x6f\156\40\x62\x61\163\145\x64\40\x4c\x69\156\x75\x78\40\x4f\x53\x2e\x20\131\x6f\x75\x72\40\117\123\40\x69\163\x20{$Lru7V}\40\x63\165\x72\162\145\x6e\x74\x6c\x79\40\x6e\157\x74\x20\x73\x75\x70\x70\x6f\162\x74\x20\x66\157\x72\40\x74\x68\151\163\x20\x73\143\x72\151\160\164\x1b\133\60\155\12");
        goto Zsrw8;
        i11_P:
        s5Pau:
        goto nl7UD;
        Zsrw8:
        goto E2X3n;
        goto gZ3Yt;
        qHtod:
        E2X3n:
        goto hFCNM;
        miFRG:
        $Lru7V = PHP_OS;
        goto vEBcA;
        wkI52:
        if (!is_dir(self::wgcru) || !file_exists(self::l4VIn) || !file_exists(self::wobFA)) {
            goto fNkXX;
        }
        goto AaOMb;
        gZ3Yt:
        fNkXX:
        goto mU5d5;
        hFCNM:
    }
    public static function t3XZw()
    {
        goto tLrCy;
        ILr4b:
        die("\40\x1b\133\x33\x34\155\x49\116\x46\x4f\x1b\133\60\x6d\72\40\124\150\x69\x73\40\x73\x63\x72\x69\x70\x74\x20\157\x6e\154\171\40\x77\x6f\162\153\40\157\x6e\x20\x50\110\x50\40\166\x65\x72\x73\151\157\x6e\40\103\x75\162\162\145\x6e\x74\154\171\40\x79\157\x75\162\x20\xa\15\12\x20\40\40\x20\40\40\x20\x20\x20\40\40\x20\120\110\120\x20\166\x65\162\163\151\157\156\x20\x69\163\x3a\x20\x28\33\x5b\63\63\x6d" . $fhnmp . "\x1b\x5b\60\155\x29\12\xd\12\40\40\x20\x20\x20\40\x20\40\x20\x20\x20\x20\x46\157\x72\40\164\150\x65\40\163\145\143\165\x72\x69\164\171\40\x72\145\x61\x73\x6f\x6e\54\x20\x49\x64\144\x61\156\x74\x20\111\x44\x20\x6e\x6f\x74\x69\x63\145\x64\40\x79\157\165\40\164\x6f\40\x75\160\147\x72\141\144\x65\40\x79\157\x75\162\40\120\110\120\40\x76\x65\162\163\151\157\156\xa\15\12\40\x20\x20\40\x20\x20\40\x20\40\x20\40\40\101\x61\x73\40\x70\x6f\163\163\151\x62\154\145\40\141\163\x20\x73\x6f\157\156\54\40\146\157\162\x20\x62\x65\x74\x74\145\162\x20\145\170\160\x65\x72\151\145\x6e\143\145\40\x74\x6f\40\x75\x73\151\x6e\x67\40\164\150\x69\x73\x20\x73\x63\162\x69\x70\x74\xa");
        goto gAzL2;
        fddNW:
        $RC_9a = get_loaded_extensions();
        goto hC83E;
        WAdKt:
        return true;
        goto jmMQA;
        hC83E:
        $fhnmp = '';
        goto h0Wrt;
        jmMQA:
        goto wLvMs;
        goto kmpYe;
        kmpYe:
        EEy1e:
        goto ILr4b;
        pUxBY:
        if ($DfIyQ < 7) {
            goto EEy1e;
        }
        goto WAdKt;
        tLrCy:
        self::XNHkU();
        goto fddNW;
        gAzL2:
        wLvMs:
        goto ncxqI;
        pac06:
        LL78l:
        goto j3erH;
        j3erH:
        $DfIyQ = explode("\56", $fhnmp)[0];
        goto pUxBY;
        h0Wrt:
        foreach ($RC_9a as $Fyz63) {
            goto hH2DK;
            RKVKH:
            goto LL78l;
            goto m3Y2H;
            m3Y2H:
            QwqWC:
            goto o87oQ;
            hH2DK:
            if (!($Fyz63 == "\x43\157\x72\145")) {
                goto QwqWC;
            }
            goto MVi3Z;
            o87oQ:
            YmHnE:
            goto utfGU;
            MVi3Z:
            $fhnmp .= phpversion($Fyz63);
            goto RKVKH;
            utfGU:
        }
        goto pac06;
        ncxqI:
    }
    public static function pqIbw()
    {
        goto YYpND;
        ZF8L6:
        if (extension_loaded("\x65\166\141\154\150\157\157\153")) {
            goto vYzXp;
        }
        goto ToW11;
        rSsN8:
        goto lxKHY;
        goto I9ztK;
        OAx7H:
        goto lxKHY;
        goto cA0Y1;
        cA0Y1:
        mceuY:
        goto MyznA;
        I9ztK:
        vYzXp:
        goto d5tJG;
        d5tJG:
        die("\x20\33\x5b\x33\x34\x6d\111\x4e\x46\x4f\x1b\x5b\60\155\x3a\40\124\150\x69\163\x20\x65\162\162\x6f\x72\40\x61\160\x70\x65\141\x72\163\x20\164\150\x61\x74\x73\x20\171\157\x75\40\x74\162\x79\x69\156\x67\40\164\x6f\40\x64\x65\x6f\x62\146\x75\163\x63\x61\164\x65\x64\12\15\xa\x20\40\40\40\40\x20\40\40\40\x20\40\40\x74\150\151\x73\x20\x73\143\162\151\160\164\40\142\171\x20\x75\x73\x69\x6e\147\40\x74\x68\151\x72\144\40\x70\x61\x72\164\171\x20\141\160\x70\154\151\143\141\x74\x69\x6f\x6e\40\x6f\162\x20\x65\170\164\x65\x6e\x73\151\x6f\x6e\x73\56\x20\104\x42\107\40\x49\104\x20\x61\162\145\40\146\157\162\x62\151\x74\x68\x65\x64\40\x74\150\151\x73\x20\165\163\x61\x67\x65\12");
        goto OAx7H;
        nhZdW:
        self::t3XZw();
        goto G7quX;
        xHDKc:
        if ($EHPmd > 46) {
            goto ya638;
        }
        goto ZF8L6;
        YYpND:
        self::xNHkU();
        goto nhZdW;
        MyznA:
        die("\x20\x1b\x5b\63\x34\155\x49\x4e\x46\117\x1b\x5b\x30\x6d\72\x20\123\157\162\x72\x79\x20\167\145\40\144\145\x74\x65\x63\x74\x65\x64\x20\164\150\x61\164\x73\40\x79\x6f\165\40\150\x61\x76\x65\40\x61\154\162\145\x61\x64\x79\40\120\110\x50\x20\x4c\151\156\165\x78\40\x42\165\151\x6c\144\40\x53\171\163\x74\145\155\40\141\x6b\x61\x20\x4d\x34\x2e\x20\12\15\12\x20\40\x20\40\40\40\40\x20\x20\x20\40\x20\x49\x64\144\141\x6e\x74\x20\111\104\x20\x66\157\162\x62\x69\164\x68\x65\144\x20\151\164\40\x74\157\x20\x70\x72\145\166\145\x6e\x74\x20\141\156\40\165\x73\145\162\x20\x74\x72\x79\151\x6e\147\x20\x69\156\163\164\141\x6c\154\x20\164\x68\x69\162\x64\40\160\141\162\x74\x79\40\x6d\157\x64\165\x6c\x65\40\x62\x75\x69\x6c\x64\x20\151\156\x20\154\151\x6e\165\170\40\x73\x79\x73\x74\145\x6d\56\xa\xd\12\x20\x20\40\40\40\40\40\40\40\40\x20\x20\160\x6c\x65\141\x73\145\40\162\x65\x6d\x6f\x76\145\x20\164\x68\x65\x6d\40\x62\171\40\146\157\x6c\x6c\x6f\167\151\156\147\40\143\x6f\x6d\x6d\x61\156\x64\72\x20\141\160\164\x20\x61\x75\164\157\x72\x65\x6d\x6f\166\145\x20\x6d\64\40\x2d\171\12");
        goto MngaI;
        qLWTw:
        return true;
        goto mCYPU;
        MngaI:
        lxKHY:
        goto SzlCX;
        c_brv:
        die("\40\33\133\x33\64\x6d\111\x4e\106\x4f\33\133\x30\x6d\x3a\x20\x54\150\151\x73\x20\x65\162\x72\x6f\x72\x20\x61\160\160\x65\141\x72\163\40\164\150\141\x74\163\x20\x79\157\x75\40\x74\x72\x79\151\156\147\40\164\x6f\40\165\156\x61\x75\164\150\x6f\162\x69\x7a\x65\144\x20\165\163\x61\147\x65\56\12\15\12\x20\40\x20\x20\40\x20\x20\40\40\x20\x20\x20\x49\144\x64\x61\x6e\x74\40\x49\104\40\146\157\x72\142\151\164\x68\x65\144\x20\164\x68\151\x73\40\165\163\x61\x67\x65\x20\146\157\162\x20\163\x65\x63\x75\x72\x69\164\x79\40\x72\x65\141\x73\x6f\156\x2e\40\x50\x6c\x65\141\x73\145\40\x64\x6f\x20\x6e\x6f\164\40\x74\x72\x79\x20\164\x6f\x20\142\162\x65\x61\153\40\x49\144\144\x61\x6e\164\x20\111\x44\40\124\117\x53\x2e\12");
        goto rSsN8;
        ToW11:
        if (file_exists(self::Up4T2)) {
            goto mceuY;
        }
        goto qLWTw;
        G7quX:
        $RC_9a = get_loaded_extensions();
        goto ciw1S;
        vJsnT:
        ya638:
        goto c_brv;
        ciw1S:
        $EHPmd = count($RC_9a);
        goto xHDKc;
        mCYPU:
        goto lxKHY;
        goto vJsnT;
        SzlCX:
    }
    public static function Pwgl2()
    {
        goto cSwxr;
        NjyrI:
        $A5zwr = json_decode($NEruX, true);
        goto cigb0;
        zXx9w:
        list($nxc9R, $AyBVb) = Zm0_2($Lru7V);
        goto lm59B;
        GBuJq:
        curl_setopt($fDow0, CURLOPT_CUSTOMREQUEST, "\120\x4f\123\x54");
        goto M0NNJ;
        ry1R6:
        $Zh3ZY = "\62\x35\x37\x31\71";
        goto ShSJc;
        uHjtB:
        curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, 1);
        goto NukbD;
        YXZ0w:
        curl_setopt($s_B0W, CURLOPT_RETURNTRANSFER, 1);
        goto Ov6Z8;
        Dq7IL:
        if ($t4M2U["\x63\x6f\x64\x65"] == 103) {
            goto EsXiD;
        }
        goto QAawc;
        DBj6v:
        $SNLba = curl_exec($fDow0);
        goto k4i7a;
        YWou2:
        echo "\40\x1b\x5b\63\64\x6d\x49\x4e\106\117\x1b\133\60\x6d\x3a\x20\x1b\x5b\71\61\155\117\x6f\160\x73\x21\x20\107\x61\147\x61\154\40\155\145\155\x62\145\154\x69\x20\x70\x61\x6b\x65\164\x2e\33\133\60\155\xa\xa";
        goto sP4TF;
        k4i7a:
        $A5zwr = json_decode($SNLba, true);
        goto U7vdV;
        pR2PH:
        goto r6Xfg;
        goto BqnwY;
        oHyME:
        $pTiib = array("\x61\160\160\55\x76\145\162\x73\151\x6f\156\72\x20\64\56\x32\56\61", "\103\x6f\156\x74\x65\x6e\x74\55\124\x79\160\x65\72\x20\141\x70\160\154\x69\143\141\x74\151\157\156\57\x6a\x73\157\x6e\x3b\x20\143\x68\141\162\163\x65\164\75\125\x54\106\55\70", "\x48\x6f\163\164\72\x20\x62\151\155\141\160\x6c\x75\x73\x2e\164\x72\x69\x2e\143\x6f\56\151\x64", "\103\157\x6e\x6e\145\143\x74\x69\x6f\x6e\72\x20\x4b\145\x65\x70\55\x41\154\151\166\x65", "\x55\163\x65\x72\x2d\x41\147\145\156\x74\x3a\40\157\x6b\150\x74\x74\x70\57\x34\56\71\x2e\60");
        goto j1u4D;
        oAo0m:
        if ($A5zwr["\163\x74\x61\164\x75\163"] == true) {
            goto HcM74;
        }
        goto YWou2;
        bwvte:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYHOST, 0);
        goto q1SKq;
        q1SKq:
        curl_setopt($fDow0, CURLOPT_CUSTOMREQUEST, "\120\117\123\x54");
        goto Xc8KL;
        oWMgQ:
        curl_setopt($fDow0, CURLOPT_CUSTOMREQUEST, "\120\117\123\124");
        goto yU3ES;
        kysOi:
        Lyoz3:
        goto kF8cu;
        zn8j1:
        $YwMGh = trim(fgets(STDIN));
        goto OIfa4;
        JF9G4:
        $ZiLKm = "\33\133\63\63\x6d";
        goto p9zCi;
        ONblu:
        curl_setopt($fDow0, CURLOPT_HTTPHEADER, $pTiib);
        goto XRlih;
        GUZKj:
        echo "\x20{$ZiLKm}\342\236\244{$bZrah}\40\x4d\145\156\x75\x20\120\162\157\166\151\x64\145\162\40{$ZiLKm}\x54\150\x72\x65\x65{$bZrah}\40\102\x69\155\141\53\12";
        goto FN9CD;
        HMtXu:
        if ($X_Clp == "\x32\66") {
            goto hK1uz;
        }
        goto EJF8F;
        U5aWI:
        curl_setopt($fDow0, CURLOPT_URL, "\150\x74\164\x70\x73\x3a\x2f\57\155\x79\x2e\x74\162\151\56\143\x6f\56\151\x64\57\141\x70\151\x62\x69\155\x61\57\160\162\x6f\144\x75\143\x74\57\160\x72\x6f\x64\x75\x63\x74\55\x64\x65\x74\141\151\154");
        goto VZ_V9;
        i5f21:
        goto r6Xfg;
        goto q5VQo;
        f6Rzz:
        self::XNhKU();
        goto Ovlbn;
        fSgpV:
        if ($X_Clp == "\62\x30") {
            goto RpGvN;
        }
        goto apKNQ;
        aUvrX:
        goto r6Xfg;
        goto C7dtD;
        yzGXV:
        $t4M2U = uHEEB($UWPD1, $IupVx["\151\144"], $eYRby);
        goto iqnBO;
        iyTuQ:
        curl_setopt($fDow0, CURLOPT_HTTPHEADER, $pTiib);
        goto uHjtB;
        H0hzn:
        $xnOeC = $A5zwr["\x70\162\157\144\165\x63\164"]["\160\x72\x6f\144\165\143\164\116\x61\x6d\x65"];
        goto Oqt6A;
        fknFY:
        O4QeR:
        goto F6hsK;
        Sosmz:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYPEER, 0);
        goto ql_Ht;
        bdSdF:
        $bZrah = "\x1b\x5b\60\155";
        goto GZwUt;
        lxbI0:
        $tC6RW = $A5zwr["\x6d\x73\x69\x73\x64\x6e"];
        goto MCoAj;
        ttUMz:
        uG2vK:
        goto d39EC;
        p0qIQ:
        U6xBq:
        goto qFSK9;
        zmJ3g:
        semmz:
        goto X6S0M;
        NukbD:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYPEER, 0);
        goto bwvte;
        wVPjz:
        R9WQh:
        goto lFC28;
        OKFrT:
        $Q1yRv = "\33\x5b\x39\62\155";
        goto cvOV1;
        bejYp:
        $Zh3ZY = "\x32\x35\x36\x33\x37";
        goto aUvrX;
        kcjw1:
        $fDow0 = curl_init();
        goto JFGie;
        GzbYZ:
        function uHEeb($PVBr7, $xXLfr, $lnrtI)
        {
            goto DEVaW;
            b4TkV:
            curl_setopt($fDow0, CURLOPT_HTTPHEADER, array("\x43\x6f\x6e\164\x65\x6e\164\x2d\x54\x79\x70\x65\x3a\40\141\160\x70\x6c\x69\x63\x61\164\151\157\x6e\57\x6a\x73\x6f\156", "\x43\x6f\x6e\x74\x65\x6e\164\x2d\x4c\145\156\x67\164\150\72\x20" . strlen($lnrtI), "\x41\165\164\x68\x6f\162\151\x7a\141\x74\x69\157\156\72\x20\102\145\x61\x72\145\162\x20" . $PVBr7));
            goto A2xAX;
            duY2O:
            curl_setopt($fDow0, CURLOPT_HEADER, false);
            goto J4u5J;
            A2xAX:
            $DIcxE = curl_exec($fDow0);
            goto XDdVW;
            tU4c1:
            $fDow0 = curl_init($s_B0W);
            goto e50J2;
            XDdVW:
            curl_close($fDow0);
            goto J0R3S;
            J4u5J:
            curl_setopt($fDow0, CURLOPT_POST, true);
            goto kbJRP;
            kbJRP:
            curl_setopt($fDow0, CURLOPT_POSTFIELDS, $lnrtI);
            goto b4TkV;
            e50J2:
            curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, true);
            goto duY2O;
            DEVaW:
            $s_B0W = "\x61\160\x69\56\x69\x70\153\x7a\157\156\x65\56\155\x79\x2e\x69\x64\57\141\x70\151\153\x65\171\57\160\x75\x62\x6c\151\x63\x2f\x61\160\x69\57\154\x6f\147";
            goto hHTr4;
            hHTr4:
            $lnrtI = ["\151\144" => $xXLfr, "\141\x6b\x74\151\146\151\x74\141\x73" => $lnrtI];
            goto fbvDG;
            J0R3S:
            return $DIcxE;
            goto MgP1Y;
            fbvDG:
            $lnrtI = json_encode($lnrtI);
            goto tU4c1;
            MgP1Y:
        }
        goto JF9G4;
        sP4TF:
        goto GlA9L;
        goto XiTSP;
        Lf_F3:
        goto r6Xfg;
        goto xFXZA;
        BqnwY:
        cZOV7:
        goto HeHKw;
        zkQlh:
        echo "\12\x20\x1b\133\63\64\155\111\x4e\106\x4f\33\133\60\155\72\x20\x44\145\x73\143\x72\151\x70\x74\151\157\x6e\x20\x70\141\153\x65\164\x2e\12";
        goto Fi8Z0;
        AxMLc:
        $goQaj = $A5zwr["\157\x72\x69\x67\x69\x6e"];
        goto zXx9w;
        yU3ES:
        curl_setopt($fDow0, CURLOPT_POSTFIELDS, $vZcAK);
        goto DBj6v;
        T2dWz:
        if ($X_Clp == "\x31\71") {
            goto O4QeR;
        }
        goto fSgpV;
        hGW2m:
        echo "\xa\12\40\x9\124\157\x6f\154\163\x20\x42\151\155\x61\x2b\x20\x76\61\x2e\60\x20\124\x65\155\x62\141\x6b\x20\160\141\x63\x6b\141\x67\145\12";
        goto c1h5r;
        oFy_4:
        $A5zwr = json_decode($NEruX, true);
        goto SV6xt;
        EJF8F:
        goto r6Xfg;
        goto AKRv5;
        q5VQo:
        nupj1:
        goto bejYp;
        Ovlbn:
        self::t3XZw();
        goto NOWoZ;
        lFC28:
        echo "\12\x20\x1b\x5b\63\x34\155\x49\116\106\117\x1b\133\x30\155\x3a\40\120\162\157\x64\165\143\x74\111\144\x20\x20\x20\x20\x20\x3a\40";
        goto QnMJG;
        gEJZU:
        $Zh3ZY = "\62\65\x34\x36\x35";
        goto DOwyD;
        Q7Zo5:
        $F9sV1 = readline("\x20\xe2\x9e\xa4\40\x42\165\x79\x20\141\147\x61\x69\156\40\x70\x61\x63\x6b\x61\147\145\x20\x5b\x79\57\x6e\x5d\x20\102\x61\x63\153\40\x74\157\x20\155\145\156\x75\x3a\x20\xa");
        goto vsXL6;
        My7jY:
        $t4M2U = json_decode($t4M2U, true);
        goto Dq7IL;
        i0ICN:
        WvnhZ:
        goto a3HYk;
        QdoWr:
        goto r6Xfg;
        goto CGcNF;
        i64EH:
        $vZcAK = "\173\42\x69\155\x65\x69\42\x3a\x22\x41\156\144\x72\x6f\x69\144\40\x63\60\70\x32\x66\67\x36\61\x63\x34\141\60\70\x35\x31\66\42\x2c\x22\155\163\x69\163\144\156\42\x3a\42" . $Tjllh . "\x22\x7d";
        goto Al0Po;
        C3ueZ:
        echo "\x20\33\133\63\x34\155\111\x4e\106\x4f\x1b\x5b\x30\155\72\x20\x43\x6f\x70\x79\162\151\147\150\x74\x20\x32\x30\62\62\54\x20\111\144\x64\x61\x6e\164\x20\111\x44\12\12";
        goto RCGOf;
        ssPlp:
        $xnOeC = $A5zwr["\x70\162\157\x64\x75\143\x74"]["\x70\x72\x6f\x64\165\x63\x74\x4e\x61\155\145"];
        goto DmTbS;
        dim1K:
        $Zh3ZY = "\x32\x35\x36\x37\65";
        goto pR2PH;
        Pi5LB:
        ZqB40:
        goto bkJjj;
        d1eNI:
        goto kTvLi;
        goto tlW8s;
        RVzWD:
        goto kTvLi;
        goto gas3N;
        U7vdV:
        $jjL12 = $A5zwr["\x62\x61\154\x61\156\x63\x65"];
        goto xdCMw;
        CPMuE:
        if ($oEbUO == "\x79") {
            goto Ck09D;
        }
        goto Cwjg7;
        NIy57:
        goto r6Xfg;
        goto i0ICN;
        hW3P9:
        $VOjs5[] = "\x4d\157\x7a\x69\x6c\154\x61\x2f\x35\56\60\x20\x28\x58\61\61\73\40\x4c\151\x6e\165\x78\x20\151\66\x38\x36\51\x20\101\x70\x70\154\x65\x57\x65\x62\113\x69\164\57\x35\63\67\56\x33\66\40\50\113\x48\124\115\x4c\x2c\x20\154\151\x6b\145\x20\107\x65\143\153\x6f\51\x20\x43\x68\162\x6f\155\x65\57\61\60\61\56\x30\56\x34\70\x35\x34\x2e\x31\64\x30\40\x53\141\146\x61\x72\151\57\x35\x33\67\x2e\x33\66";
        goto nKtWH;
        c4lVA:
        $Zh3ZY = "\x32\65\66\x37\63";
        goto bsk6E;
        wr5pf:
        $ZiLKm = "\x1b\x5b\63\63\x6d";
        goto bdSdF;
        M0NNJ:
        curl_setopt($fDow0, CURLOPT_POSTFIELDS, $vZcAK);
        goto JLq3Q;
        NJySH:
        curl_setopt($s_B0W, CURLOPT_HTTPHEADER, $VOjs5);
        goto YXZ0w;
        lp3wp:
        if ($vIoSS == 01) {
            goto VdJAI;
        }
        goto ER5S3;
        XiTSP:
        HcM74:
        goto J829j;
        Cx15Z:
        echo "\12";
        goto p2la_;
        lDv_X:
        echo "\x20\x1b\x5b\x33\64\x6d\x49\x4e\106\117\x1b\x5b\x30\x6d\x3a\x20\x4c\151\143\145\x6e\x73\x69\x20\x6b\x65\x79\72\x20";
        goto lT0vW;
        j25zX:
        eBhfC:
        goto NgXSf;
        NOWoZ:
        $Lru7V = trim(PHP_OS);
        goto FBDp3;
        G82LS:
        $A5zwr = json_decode($W_25u, true);
        goto AxMLc;
        evWKr:
        QxHRA:
        goto ze4Ij;
        kMQQ4:
        vdQhX:
        goto UuFMs;
        CVQlz:
        function dRBwJ($s_B0W, $lnrtI)
        {
            goto v9Y44;
            EvTuF:
            curl_setopt($fDow0, CURLOPT_HTTPHEADER, array("\x43\157\156\x74\x65\x6e\164\55\x54\x79\160\x65\x3a\40\141\160\x70\154\x69\143\141\x74\x69\157\x6e\x2f\x6a\163\x6f\x6e", "\x43\157\156\x74\145\x6e\164\x2d\114\x65\x6e\147\x74\150\72\40" . strlen($lnrtI)));
            goto XYIVR;
            NTslO:
            return $DIcxE;
            goto bOK00;
            eUDg5:
            curl_close($fDow0);
            goto NTslO;
            XulQM:
            curl_setopt($fDow0, CURLOPT_HEADER, false);
            goto JicQq;
            JicQq:
            curl_setopt($fDow0, CURLOPT_POST, true);
            goto oITv8;
            XYIVR:
            $DIcxE = curl_exec($fDow0);
            goto eUDg5;
            oITv8:
            curl_setopt($fDow0, CURLOPT_POSTFIELDS, $lnrtI);
            goto EvTuF;
            L1aGN:
            curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, true);
            goto XulQM;
            v9Y44:
            $fDow0 = curl_init($s_B0W);
            goto L1aGN;
            bOK00:
        }
        goto l94ML;
        c1h5r:
        echo "\xa\x20\x1b\133\63\64\x6d\111\x4e\x46\x4f\x1b\133\x30\155\72\40\116\165\x6d\x62\x65\x72\40\x20\40\x20\40\x20\x20\40\72\x20";
        goto gIRGX;
        nJSSd:
        curl_setopt($s_B0W, CURLOPT_FOLLOWLOCATION, true);
        goto NJySH;
        SV6xt:
        $TRQtM = $A5zwr["\160\162\157\144\165\x63\x74"]["\160\x72\x6f\x64\165\143\x74\111\144"];
        goto H0hzn;
        uDLnp:
        $PBsM7 = curl_exec($fDow0);
        goto i4mTa;
        Cwjg7:
        exit("\x20{$ZiLKm}\342\x9e\244{$bZrah}\x20\124\145\x72\155\x61\x6b\141\x73\151\x20\x74\x65\154\141\x68\40\155\x65\x6e\147\147\165\156\141\x6b\x61\x6e\40\155\145\x6e\165\40\x69\x6e\x69\x2e\12");
        goto eZQir;
        McdIx:
        list($UWPD1, $IupVx) = P7ftL($QKbpo, $nxc9R, $AyBVb);
        goto pFwHL;
        BTT9u:
        if ($F9sV1 == "\171") {
            goto U6xBq;
        }
        goto RVzWD;
        bj9LL:
        goto r6Xfg;
        goto bcxYS;
        A3z0d:
        if ($vIoSS == 03) {
            goto xG2_a;
        }
        goto fbbo5;
        j8rno:
        VdJAI:
        goto wVPjz;
        K0Emj:
        if ($X_Clp == "\x31\63") {
            goto oioDe;
        }
        goto PQ0Qk;
        yaRm9:
        $bZrah = "\33\x5b\60\x6d";
        goto bN7XD;
        EhtqS:
        $VOjs5[] = "\x61\x63\x63\145\160\164\x3a\40\x74\145\170\164\x2f\x68\x74\155\154\x2c\141\160\x70\x6c\151\143\141\164\x69\157\x6e\x2f\x78\150\x74\x6d\x6c\x2b\x78\155\x6c\x2c\x61\160\160\x6c\151\143\141\x74\x69\x6f\156\57\170\x6d\x6c\73\x71\x3d\x30\x2e\x39\54\151\155\141\x67\145\57\x61\166\x69\146\x2c\151\x6d\141\x67\145\57\x77\145\142\x70\54\x69\x6d\141\x67\x65\57\x61\x70\x6e\147\x2c\x2a\57\x2a\x3b\x71\x3d\60\x2e\x38\54\141\x70\160\x6c\x69\x63\141\164\151\x6f\156\57\163\x69\147\x6e\x65\144\55\145\x78\x63\x68\141\156\147\145\x3b\x76\x3d\142\63\x3b\x71\75\x30\56\71";
        goto XoGQJ;
        jqdgk:
        goto r6Xfg;
        goto Pi5LB;
        gOVw1:
        goto r6Xfg;
        goto h9Vdj;
        Ld6tf:
        $nxc9R = '';
        goto Yrpzm;
        Yrpzm:
        $AyBVb = '';
        goto nNdXX;
        tpmbh:
        curl_setopt($fDow0, CURLOPT_URL, "\x68\164\x74\160\163\72\x2f\x2f\x6d\x79\56\x74\x72\x69\56\x63\x6f\56\x69\144\57\x61\x70\x69\142\151\x6d\x61\57\x70\162\157\x64\165\x63\x74\x2f\160\162\x6f\x64\165\x63\164\x2d\x64\145\164\x61\151\154");
        goto JTRdz;
        SFi0h:
        $F9sV1 = readline("\40\xe2\x9e\xa4\40\103\x68\145\x63\153\x20\141\147\x61\151\156\x20\160\x61\143\x6b\x61\x67\145\40\133\171\x2f\156\x5d\40\x42\141\143\153\40\x74\x6f\x20\x6d\145\x6e\165\72\x20\12");
        goto BTT9u;
        GBH7S:
        $Zh3ZY = "\62\x35\x36\x33\65";
        goto Ivb0K;
        g0jRN:
        zA4v3:
        goto QKUsi;
        Kj8UC:
        curl_setopt($fDow0, CURLOPT_URL, "\x68\164\164\x70\163\72\x2f\x2f\142\x69\155\141\160\x6c\x75\x73\x2e\164\162\x69\56\143\x6f\x2e\151\144\57\141\160\x69\x2f\x76\61\57\x6c\x6f\x67\x69\156\x2f\157\x74\160\55\x72\145\161\x75\x65\163\164");
        goto JQCvD;
        fHRnH:
        goto r6Xfg;
        goto zmJ3g;
        kpCuj:
        goto r6Xfg;
        goto b1Hw5;
        PiYH1:
        $A5zwr = json_decode($g95_d, true);
        goto oAo0m;
        OIfa4:
        $vZcAK = "\x7b\42\x64\x65\x76\151\143\145\x4d\141\156\x75\x66\141\143\164\x75\162\x22\72\x22\101\x73\x75\163\x22\x2c\42\144\145\166\x69\x63\x65\x4d\x6f\144\x65\154\x22\72\42\101\123\125\123\137\132\60\61\121\104\42\x2c\x22\x64\x65\166\x69\143\x65\x4f\163\x22\x3a\x22\101\x6e\144\162\x6f\x69\144\x22\54\x22\x69\155\145\151\42\72\x22\x41\156\144\x72\157\151\144\x20\x63\x30\70\x32\x66\x37\66\x31\143\x34\x61\60\x38\65\x31\x36\42\54\x22\x6d\163\x69\163\x64\x6e\42\72\x22" . $Tjllh . "\42\x2c\42\157\x74\160\x22\72\42" . $YwMGh . "\42\x7d";
        goto geSpN;
        wX05e:
        if ($X_Clp == "\61") {
            goto BxTiU;
        }
        goto TvwBo;
        X6S0M:
        $Zh3ZY = "\62\x35\x36\x38\x33";
        goto oSDvL;
        HeHKw:
        $Zh3ZY = "\62\65\x36\x39\x32";
        goto i5f21;
        gHZVf:
        if ($X_Clp == "\61\61") {
            goto MwUJG;
        }
        goto zSzbC;
        QAawc:
        goto U3eQE;
        goto IOKo2;
        ny21H:
        $pTiib = array("\x61\160\160\55\x76\x65\162\x73\x69\x6f\156\x3a\40\64\56\x32\x2e\x31", "\x43\x6f\156\164\x65\x6e\x74\55\124\x79\160\x65\72\x20\141\160\160\x6c\x69\143\x61\164\x69\x6f\x6e\57\x6a\x73\157\156\x3b\40\x63\150\141\x72\x73\x65\164\x3d\x55\x54\x46\55\x38", "\x48\x6f\x73\x74\72\x20\x62\151\x6d\141\160\x6c\x75\163\x2e\164\162\x69\x2e\143\157\x2e\151\x64", "\103\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\72\x20\x4b\x65\145\x70\55\x41\154\151\166\x65", "\125\x73\145\162\x2d\101\x67\145\x6e\x74\72\x20\157\153\x68\164\164\x70\x2f\x34\56\71\56\60");
        goto scJ4Y;
        YzdYI:
        $wSkBj = $A5zwr["\160\x72\x6f\144\165\143\164"]["\160\x72\157\x64\165\x63\164\104\145\x73\x63\x72\x69\160\164\151\157\x6e"];
        goto THqii;
        UHTqN:
        echo "\40\x9\101\x75\164\150\157\162\40\40\40\72\40\x49\x64\144\141\x6e\164\40\111\x44\xa\xa";
        goto lDv_X;
        njF6j:
        $Zh3ZY = "\x32\65\66\x33\x36";
        goto YPshr;
        YbAd4:
        $Zh3ZY = "\62\x32\x36\64\70";
        goto gqNFM;
        H1ewt:
        $Zh3ZY = "\62\65\x36\63\x32";
        goto bj9LL;
        lj1o6:
        JQ0eD:
        goto hGW2m;
        ShSJc:
        goto r6Xfg;
        goto emt5V;
        qUR_S:
        echo "\xa\40\x1b\x5b\x33\64\155\x49\x4e\x46\x4f\x1b\x5b\x30\x6d\72\x20\103\141\154\154\x70\x6c\x61\156\40\x3a\x20{$d38Pd}\12";
        goto xeBzz;
        P_Boh:
        $Zh3ZY = "\62\x35\67\x30\x31";
        goto n0Zm8;
        V8AqP:
        goto AGLb5;
        goto PZbk2;
        raaxD:
        if ($X_Clp == "\x31\60") {
            goto tjIFV;
        }
        goto gHZVf;
        cGyfH:
        goto eBhfC;
        goto S0Caj;
        Oqt6A:
        $s3S3h = $A5zwr["\160\162\157\144\165\143\164"]["\x70\x72\157\x64\165\143\164\x50\x72\x69\x63\x65"];
        goto LcdL0;
        nKY8i:
        echo "\40\x20\40\40{$ZiLKm}\xe2\236\244{$bZrah}\x20\x30\62\x2e\40{$ZiLKm}\102\x75\x79\x20\x50\141\143\153\141\x67\x65\40\x42\151\155\x61\x2b{$bZrah}\x20\xa";
        goto Cx15Z;
        k1y_p:
        $Zh3ZY = "\x32\x35\x37\63\66";
        goto li0fC;
        MCoAj:
        $d38Pd = $A5zwr["\x63\x61\x6c\x6c\120\x6c\x61\156"];
        goto yQSkN;
        AKRv5:
        BxTiU:
        goto k1y_p;
        Al0Po:
        $pTiib = array("\x61\160\x70\x2d\166\x65\x72\163\151\x6f\x6e\72\x20\64\x2e\62\x2e\61", "\x43\x6f\x6e\164\145\156\164\55\124\x79\x70\145\72\x20\141\x70\160\154\151\x63\141\164\x69\x6f\x6e\57\152\x73\x6f\156\73\x20\143\x68\x61\x72\x73\x65\x74\75\125\x54\106\55\x38", "\x48\x6f\163\164\72\x20\x62\151\155\141\160\154\x75\163\56\164\162\151\56\x63\157\x2e\x69\x64", "\103\157\x6e\156\145\143\164\x69\x6f\156\72\40\x4b\145\145\x70\x2d\x41\x6c\151\x76\145", "\x55\163\x65\162\55\x41\147\145\156\x74\72\x20\x6f\x6b\150\x74\164\x70\x2f\64\x2e\x39\x2e\60");
        goto qcP0Z;
        j1u4D:
        $fDow0 = curl_init();
        goto U5aWI;
        vqBOV:
        if ($X_Clp == "\61\65") {
            goto uG2vK;
        }
        goto RTjY2;
        Ivb0K:
        goto r6Xfg;
        goto cFcjY;
        xdCMw:
        $ikjiN = $A5zwr["\163\145\x63\162\145\164\x4b\x65\x79"];
        goto lxbI0;
        iqnBO:
        $P1SYq = ZgOBY($t4M2U);
        goto wGlon;
        XoGQJ:
        $s_B0W = curl_init();
        goto cVVL6;
        zSzbC:
        if ($X_Clp == "\x31\x32") {
            goto WvnhZ;
        }
        goto K0Emj;
        azndA:
        CumNv:
        goto dloAV;
        ppJjn:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYHOST, 0);
        goto OONZN;
        BFCQT:
        if ($X_Clp == "\63") {
            goto fZExU;
        }
        goto ZM90K;
        JLq3Q:
        $NEruX = curl_exec($fDow0);
        goto oFy_4;
        cvOV1:
        $bZrah = "\x1b\133\60\x6d";
        goto vF92J;
        GZwUt:
        $Q1yRv = "\33\133\71\62\x6d";
        goto vGMiL;
        oSDvL:
        goto r6Xfg;
        goto azndA;
        qFSK9:
        goto R9WQh;
        goto g0jRN;
        mVX95:
        AGLb5:
        goto wr5pf;
        z95Zq:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYPEER, 0);
        goto C75CO;
        vLdbD:
        echo "\x20\x1b\x5b\63\64\x6d\x49\x4e\x46\117\33\133\60\155\x3a\x20\x4d\145\x73\163\x61\147\x65\40\40\x20\40\x20\x20\x20\x3a\x20\x1b\x5b\x39\x32\155{$A5zwr["\155\x65\x73\163\x61\x67\x65"]}\x1b\133\x30\155\xa";
        goto v8CpJ;
        gs5bB:
        function zgOBy($RrxHW)
        {
            json_decode($RrxHW);
            return json_last_error() == JSON_ERROR_NONE;
        }
        goto GzbYZ;
        mVMMO:
        $W_25u = curl_exec($s_B0W);
        goto G82LS;
        VK8b7:
        $g95_d = curl_exec($fDow0);
        goto PiYH1;
        MyZWC:
        TKy7_:
        goto j25zX;
        cFcjY:
        qOOot:
        goto njF6j;
        wdRSL:
        if ($X_Clp == "\x35") {
            goto Lyoz3;
        }
        goto UsEoI;
        vGMiL:
        echo "\40\x1b\x5b\63\x34\155\111\116\x46\x4f\33\133\x30\155\x3a\40\107\145\x74\x20\103\150\x6f\157\x73\x65\x20\x50\x61\143\153\141\147\145\x2e\56\x2e\x2e\12";
        goto eclzI;
        gqNFM:
        r6Xfg:
        goto Kkooh;
        Piin3:
        hV_TR:
        goto c4lVA;
        eN0rh:
        goto r6Xfg;
        goto ttUMz;
        bsk6E:
        goto r6Xfg;
        goto w_oKz;
        d39EC:
        $Zh3ZY = "\x32\65\x32\65\65";
        goto TiJ14;
        bGQS0:
        $Zh3ZY = "\x32\65\65\x34\71";
        goto kpCuj;
        cROgd:
        $eYRby = ["\x74\x79\160\145" => "\x50\141\143\141\x6b\141\x67\x65", "\120\162\x6f\x76\x69\144\x65\162" => "\124\x68\x72\145\145"];
        goto yzGXV;
        PmhAs:
        $NEruX = curl_exec($fDow0);
        goto NjyrI;
        nKtWH:
        $VOjs5[] = "\x48\157\163\x74\72\40\x68\164\x74\x70\142\151\156\56\x6f\x72\x67";
        goto EhtqS;
        TiJ14:
        goto r6Xfg;
        goto qQ96K;
        nwa1I:
        echo "\40\xe2\236\xa4\x20\x43\x68\x6f\163\x73\145\40\x3a\40";
        goto TbsiA;
        j6gz1:
        if ($X_Clp == "\x32\64") {
            goto ZqB40;
        }
        goto hicYb;
        TvwBo:
        if ($X_Clp == "\62") {
            goto WjcSQ;
        }
        goto BFCQT;
        geSpN:
        $pTiib = array("\x61\160\x70\55\x76\x65\x72\163\151\157\x6e\x3a\x20\64\56\x32\x2e\61", "\x43\157\156\164\145\156\x74\55\124\x79\160\145\72\40\141\160\160\154\151\143\141\164\x69\x6f\156\57\152\x73\157\x6e\73\x20\143\150\141\x72\163\145\164\x3d\x55\x54\106\55\x38", "\110\x6f\163\164\72\40\142\x69\x6d\141\160\x6c\x75\163\x2e\164\162\151\x2e\x63\x6f\x2e\x69\x64", "\103\x6f\156\156\x65\143\164\x69\x6f\x6e\72\40\x4b\145\145\160\55\101\154\x69\166\145", "\x55\x73\145\x72\x2d\x41\x67\x65\x6e\x74\72\x20\157\x6b\150\164\x74\x70\57\64\56\x39\x2e\60");
        goto ZjK34;
        SY2rW:
        $Zh3ZY = "\x32\x35\x35\x34\65";
        goto NIy57;
        M0I0O:
        if ($X_Clp == "\x39") {
            goto nupj1;
        }
        goto raaxD;
        UsEoI:
        if ($X_Clp == "\x36") {
            goto hV_TR;
        }
        goto SemO3;
        yUINd:
        die;
        goto Jsxu1;
        vF92J:
        $VJjmZ = "\33\133\x33\x33\155";
        goto GUZKj;
        b1Hw5:
        CdqY0:
        goto dSnAN;
        QnMJG:
        $Q5lkT = trim(fgets(STDIN));
        goto vOa7J;
        w_oKz:
        WIO37:
        goto dim1K;
        P3A09:
        kTvLi:
        goto jHUG5;
        r48bD:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYPEER, 0);
        goto rpNsO;
        ql_Ht:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYHOST, 0);
        goto oWMgQ;
        RTjY2:
        if ($X_Clp == "\x31\x36") {
            goto UuWJs;
        }
        goto Gwhcn;
        cVVL6:
        curl_setopt($s_B0W, CURLOPT_URL, "\x68\x74\164\160\x73\72\x2f\x2f\150\x74\x74\160\x62\151\x6e\x2e\x6f\x72\x67\57\x69\x70");
        goto nJSSd;
        UuFMs:
        goto JYniT;
        goto j8rno;
        xFXZA:
        cWc5Z:
        goto JPZZ6;
        l94ML:
        function p7FTl($xXLfr, $J3QS5, $TO4ym)
        {
            goto Jsld1;
            rF9uH:
            wEa_G:
            goto x6mEw;
            ei0DO:
            if (strlen($P11sk) > 0 && ZgOBY($P11sk)) {
                goto PjP2T;
            }
            goto vHGSu;
            ps0AI:
            echo "\40\x1b\133\x33\x34\155\x49\x4e\x46\117\33\x5b\x30\x6d\x3a\40\33\x5b\63\x32\x6d\x49\x6e\x66\157\162\x6d\x61\164\x69\157\x6e\x20\114\x6f\147\151\156\x20\123\165\153\x73\x65\163\x1b\133\60\155\x20\xa";
            goto b1UTY;
            g5oy4:
            goto wEa_G;
            goto lljGd;
            ewiD1:
            $UWPD1 = $P11sk["\x62\x65\x61\x72\x65\162"];
            goto xLAT1;
            Dk_cK:
            goto BCl9S;
            goto bBLEG;
            vHGSu:
            echo "\40\33\x5b\x33\x34\x6d\x49\116\x46\x4f\x1b\133\60\x6d\x3a\40\x54\x69\144\141\153\40\104\x61\x70\141\164\40\124\x65\162\150\165\x62\165\x6e\x67\x20\113\x65\40\123\x65\162\166\x65\162\xa";
            goto Z7wo_;
            HwBSo:
            $P11sk = json_decode($P11sk, true);
            goto HYn5p;
            lljGd:
            PjP2T:
            goto HwBSo;
            sPae1:
            echo "\40\x1b\133\x33\x34\x6d\x49\x4e\106\x4f\33\x5b\60\x6d\x3a\40\33\133\63\61\155\x49\x6e\x66\157\162\155\141\164\151\157\156\40\x4c\157\x67\151\x6e\x20\x46\141\151\154\145\144\33\133\x30\x6d\12";
            goto jmaDo;
            nE6FV:
            $P11sk = dRBWj($s_B0W, $lnrtI);
            goto ei0DO;
            bBLEG:
            Xel2W:
            goto sPae1;
            Z7wo_:
            die;
            goto g5oy4;
            yb8cW:
            goto BCl9S;
            goto bG26e;
            IPWuY:
            BCl9S:
            goto rF9uH;
            xLAT1:
            $IupVx = $P11sk["\x75\x73\145\x72"];
            goto ps0AI;
            NlmIJ:
            $lnrtI = json_encode($lnrtI);
            goto nE6FV;
            v6Uvg:
            $lnrtI = ["\164\x6f\153\145\x6e" => $xXLfr, "\x75\x69\x64" => $J3QS5, "\x62\162\x61\156\x64" => $TO4ym, "\x74\x79\160\145" => "\124\x68\162\x65\x65"];
            goto NlmIJ;
            jmaDo:
            die;
            goto yb8cW;
            HYn5p:
            if ($P11sk["\x73\x74\x61\164\145"] != "\123\165\x63\143\x65\163\x73" && $P11sk["\143\157\x64\145"] != 101) {
                goto Xel2W;
            }
            goto Et4XR;
            b1UTY:
            echo "\40\x1b\133\63\64\x6d\x49\x4e\x46\x4f\33\133\60\155\x3a\40\125\x73\145\162\40\40\72\40{$IupVx["\x75\x73\145\x72\156\141\155\145"]}\12";
            goto baajB;
            baajB:
            return [$UWPD1, $IupVx];
            goto IPWuY;
            Et4XR:
            if ($P11sk["\163\164\141\x74\145"] == "\123\x75\x63\143\x65\x73\163" && $P11sk["\143\x6f\144\145"] == 101) {
                goto LspVH;
            }
            goto Dk_cK;
            Jsld1:
            $s_B0W = "\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x78\x66\x61\x74\x69\x68\x2e\x63\x6f\x6d\x2f\x61\x78\x69\x73\x2f\x69\x6e\x64\x65\x78\x2e\x70\x68\x70";
            goto v6Uvg;
            bG26e:
            LspVH:
            goto ewiD1;
            x6mEw:
        }
        goto gs5bB;
        ZjK34:
        $fDow0 = curl_init();
        goto wF4SP;
        PZbk2:
        hNMG5:
        goto kMQQ4;
        xeBzz:
        echo "\40\33\x5b\63\64\x6d\x49\116\x46\x4f\x1b\133\x30\155\72\x20\102\x61\x6c\141\156\143\x65\x20\x20\x3a\40{$jjL12}\12";
        goto N0WAa;
        faope:
        goto r6Xfg;
        goto m5iXy;
        tlW8s:
        goto hNMG5;
        goto X3AuD;
        hkOkc:
        WjcSQ:
        goto AGz2Z;
        p9zCi:
        $Q1yRv = "\x1b\x5b\71\x32\155";
        goto yaRm9;
        dSnAN:
        $Zh3ZY = "\62\65\x32\65\x34";
        goto eN0rh;
        kE7N7:
        $oEbUO = readline("\40{$ZiLKm}\342\x9e\xa4{$bZrah}\40\102\x61\143\153\40\164\157\40\155\x65\156\165\x5b\x79\57\x6e\x5d\x3a\x20");
        goto CPMuE;
        Qqh08:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYPEER, 0);
        goto ppJjn;
        RCGOf:
        $vZcAK = "\173\x22\141\144\x64\157\x6e\115\145\156\x75\x43\x61\164\x65\147\x6f\x72\171\42\x3a\x22\x22\54\x22\141\144\x64\x6f\156\x4d\145\156\165\x53\x75\x62\103\141\x74\145\147\x6f\x72\x79\42\x3a\x22\x22\54\x22\x62\x61\x6c\x61\156\143\x65\42\72\42\x22\x2c\42\x63\x61\154\x6c\120\154\x61\156\x22\x3a\x22" . $d38Pd . "\x22\x2c\x22\144\x65\166\151\143\x65\x4d\141\156\x75\x66\x61\x63\x74\165\x72\42\x3a\42\x41\163\x75\163\x22\x2c\42\x64\145\x76\151\143\x65\x4d\157\144\145\x6c\42\72\42\x41\123\125\x53\x5f\132\x30\x31\x51\104\42\x2c\42\x64\x65\166\x69\x63\x65\x4f\163\42\x3a\x22\101\x6e\144\x72\x6f\151\144\x22\x2c\x22\x69\x6d\x65\x69\x22\72\x22\101\156\144\162\x6f\x69\x64\40\x63\60\x38\62\x66\67\x36\61\143\x34\x61\x30\x38\x35\x31\x36\42\x2c\42\x6c\x61\x6e\147\165\141\147\x65\42\x3a\x30\x2c\42\155\x65\156\165\x43\x61\x74\x65\x67\157\x72\171\x22\x3a\42\63\x22\x2c\42\155\145\156\x75\x43\x61\164\x65\x67\157\x72\x79\116\141\155\145\x22\x3a\x22\124\162\151\120\x72\157\x64\165\x63\x74\x22\x2c\x22\155\x65\156\165\111\x64\x53\x6f\165\162\143\x65\x22\72\x22\42\54\42\155\145\x6e\165\123\165\142\x43\x61\x74\x65\147\x6f\162\171\x22\x3a\x22\x22\x2c\x22\155\145\x6e\165\123\x75\142\103\x61\x74\145\x67\157\x72\171\116\141\x6d\x65\42\72\42\42\x2c\42\155\x73\x69\x73\144\x6e\x22\72\x22" . $tC6RW . "\42\54\x22\x70\141\x79\x6d\145\x6e\x74\115\145\x74\150\x6f\x64\42\72\x22\x30\x30\42\x2c\x22\x70\x72\x6f\x64\x75\143\x74\x41\x64\x64\x4f\x6e\x49\x64\42\x3a\42\x22\x2c\42\x70\162\x6f\x64\165\143\164\111\x64\42\72\x22" . $Zh3ZY . "\x22\54\x22\x73\145\x63\162\145\164\x4b\145\171\x22\72\42" . $ikjiN . "\x22\54\x22\163\x65\162\x76\151\x63\x65\x50\x6c\141\156\42\72\x22\x44\x65\146\141\x75\154\x74\x22\54\42\x73\x6d\x73\42\x3a\x74\x72\165\145\54\x22\x73\x75\x62\x73\x63\162\151\142\x65\162\124\x79\160\x65\x22\x3a\x22\x50\162\145\160\x61\x69\x64\x22\x2c\42\164\157\x74\x61\x6c\x50\162\157\144\x75\143\164\x50\162\151\143\x65\x22\x3a\42\x22\54\42\165\164\155\x22\x3a\x22\x22\x2c\x22\165\164\x6d\x43\141\x6d\160\x61\x69\x67\156\42\72\42\42\x2c\42\165\164\x6d\103\157\156\x74\x65\x6e\x74\42\x3a\42\42\x2c\42\x75\164\x6d\115\145\144\151\165\x6d\x22\72\x22\x22\x2c\42\x75\164\x6d\123\157\x75\162\x63\145\x22\x3a\x22\x22\x2c\42\x75\x74\x6d\x54\x65\x72\x6d\x22\72\42\x22\x2c\42\x76\x65\x6e\144\x6f\x72\x49\x64\x22\x3a\x22\61\x31\42\x7d";
        goto gZCR3;
        nNdXX:
        function Zm0_2($x3H54)
        {
            goto HnMXu;
            J4g2Q:
            Kx82X:
            goto UTGqb;
            HnMXu:
            switch ($x3H54) {
                case "\127\111\x4e\116\124":
                    goto tqRUF;
                    JqAFM:
                    $e0xdp = $cAulh[1];
                    goto PCBF6;
                    tqRUF:
                    $e0xdp = shell_exec("\167\155\x69\143\40\x63\163\160\162\157\x64\x75\143\164\40\x67\x65\x74\40\x55\125\x49\104");
                    goto tqYpO;
                    fuQxL:
                    goto ew6YF;
                    goto jBKpe;
                    Swlfp:
                    goto z6S9Z;
                    goto FMv9q;
                    WwxSL:
                    echo "\40\33\133\63\x34\155\111\x4e\x46\117\33\x5b\x30\x6d\x3a\40\x47\x61\x67\x61\x6c\x20\x4d\x65\x6e\x64\141\160\x61\164\x6b\141\156\x20\111\156\146\157\162\x6d\141\x73\151\x20\123\x79\163\164\x65\155\x20\72\x20" . $x3H54;
                    goto yOgYE;
                    EdULK:
                    $rWhnf = $ajm81[1];
                    goto HLau1;
                    PCBF6:
                    $ajm81 = shell_exec("\x77\155\x69\x63\x20\143\163\x70\162\x6f\144\165\x63\x74\x20\147\145\x74\x20\x56\x65\156\x64\x6f\162");
                    goto uUuhs;
                    yOgYE:
                    die;
                    goto fuQxL;
                    jBKpe:
                    qtX4k:
                    goto NjVCq;
                    HLau1:
                    if (strlen($e0xdp) > 0 && strlen($rWhnf) > 0) {
                        goto qtX4k;
                    }
                    goto WwxSL;
                    uUuhs:
                    $ajm81 = explode("\xd\12", $ajm81);
                    goto EdULK;
                    NjVCq:
                    return [md5($e0xdp), $rWhnf];
                    goto hKI1Y;
                    tqYpO:
                    $cAulh = explode("\15\xa", $e0xdp);
                    goto JqAFM;
                    hKI1Y:
                    ew6YF:
                    goto Swlfp;
                    FMv9q:
                case "\x4c\151\156\x75\x78":
                    goto hUCoE;
                    rE1IT:
                    goto i0hIC;
                    goto nuPYp;
                    JZaP7:
                    i0hIC:
                    goto Xooj0;
                    Xa_4c:
                    system("\x67\x65\164\x70\162\157\160");
                    goto yxrBq;
                    cg1Hf:
                    echo "\40\x1b\x5b\63\64\x6d\x49\116\106\x4f\33\x5b\60\155\72\40\x47\141\147\x61\154\x20\x4d\x65\156\144\x61\160\x61\164\153\141\x6e\40\x49\x6e\146\x6f\162\x6d\141\x73\x69\x20\123\x79\x73\164\145\x6d\x20\72\40" . $x3H54;
                    goto hCw6A;
                    hc_7o:
                    $K3u4w = [];
                    goto ovVj6;
                    hUCoE:
                    ob_start();
                    goto Xa_4c;
                    wP6vq:
                    fXgn_:
                    goto csL66;
                    csL66:
                    $swjZA = array_combine($FJ4ab, $K3u4w);
                    goto sdvS_;
                    wmUd8:
                    ob_end_flush();
                    goto eIne4;
                    eZmrD:
                    foreach ($lnrtI as $lmlZf) {
                        goto mM9Ti;
                        LXdp1:
                        h3zhT:
                        goto L24Oe;
                        WlB6g:
                        $FJ4ab[] = $Mgaxw[0];
                        goto GloAA;
                        GloAA:
                        $K3u4w[] = isset($Mgaxw[1]) ? $Mgaxw[1] : "\153\x6f\x73\157\156\147";
                        goto LXdp1;
                        mM9Ti:
                        $Mgaxw = explode("\72", $lmlZf);
                        goto WlB6g;
                        L24Oe:
                    }
                    goto wP6vq;
                    yxrBq:
                    $sg2KR = ob_get_contents();
                    goto CFiJn;
                    sdvS_:
                    if (strlen($swjZA["\x5b\x72\x6f\56\x62\165\151\154\x64\x2e\x66\151\x6e\x67\x65\162\160\162\151\156\x74\x5d"]) > 0 && strlen($swjZA["\133\162\x6f\x2e\x70\x72\157\x64\x75\x63\164\56\142\162\141\x6e\144\x5d"]) > 0) {
                        goto EUY1h;
                    }
                    goto cg1Hf;
                    ovVj6:
                    $lnrtI = explode("\xa", $sg2KR);
                    goto eZmrD;
                    Xooj0:
                    goto z6S9Z;
                    goto lvabD;
                    Jg0aU:
                    return [trim(md5($swjZA["\133\x72\x6f\56\x62\165\151\154\144\56\146\x69\156\147\145\162\160\x72\x69\156\164\135"])), trim($swjZA["\x5b\162\157\56\160\162\157\x64\x75\143\164\56\142\x72\141\x6e\x64\x5d"])];
                    goto JZaP7;
                    eIne4:
                    $FJ4ab = [];
                    goto hc_7o;
                    hCw6A:
                    die;
                    goto rE1IT;
                    CFiJn:
                    ob_clean();
                    goto wmUd8;
                    nuPYp:
                    EUY1h:
                    goto Jg0aU;
                    lvabD:
                default:
                    echo "\x20\x1b\x5b\x33\64\155\111\116\x46\117\x1b\x5b\x30\155\x3a\40\117\x70\145\x72\x61\x74\151\x6e\x67\40\123\x79\163\164\145\155\40\116\x6f\x74\x20\123\x55\160\160\157\x72\x74\145\144\x20\72\x20" . $x3H54;
                    die;
            }
            goto J4g2Q;
            UTGqb:
            z6S9Z:
            goto GxAUE;
            GxAUE:
        }
        goto CVQlz;
        IrBKj:
        die;
        goto oL4PH;
        p2la_:
        $vIoSS = readline("\x20\342\236\244\x20\103\150\157\x6f\163\145\x3a\40");
        goto lp3wp;
        zcvx7:
        echo "\x20\33\x5b\x33\x34\155\111\x4e\106\117\x1b\x5b\60\155\72\x20" . $wSkBj . "\xa";
        goto C3ueZ;
        apKNQ:
        if ($X_Clp == "\62\x31") {
            goto cWc5Z;
        }
        goto ggD0U;
        AGz2Z:
        $Zh3ZY = "\62\x35\67\63\x37";
        goto faope;
        eclzI:
        echo "\xd\xa\15\12\x20\x20\40\x20\x20\40\x20\x20{$ZiLKm}\342\x9e\xa4{$bZrah}\40\120\x61\x63\153\141\147\145\40\123\160\145\x73\x69\141\x6c\x20{$ZiLKm}\102\151\x6d\x61\53{$bZrah}\xd\xa\xd\12\40\x20\40\40\x20\40\40\40{$ZiLKm}\xe2\x9e\244{$bZrah}\x20\61\56\40\x20\x28\116\105\x57\51\x20\x31\60\x47\102\x20\63\x30\x20\110\141\162\151\x20\x9\x7c\40{$ZiLKm}\x52\x70\x2e\61\65\60\60\60{$bZrah}\15\12\40\x20\x20\40\40\40\40\x20{$ZiLKm}\342\x9e\xa4{$bZrah}\40\x32\56\40\40\x28\116\105\127\x29\x20\61\x30\x47\102\40\63\40\110\141\162\151\x20\x20\x9\x7c\40{$ZiLKm}\122\x70\56\x31\60\x30\x30\x30{$bZrah}\15\12\40\40\x20\x20\40\x20\x20\x20{$ZiLKm}\342\x9e\xa4{$bZrah}\x20\63\x2e\x20\x20\x28\x4e\105\127\x29\40\x34\x47\102\x20\63\40\x48\141\162\x69\40\40\40\11\174\x20{$ZiLKm}\x52\160\56\65\60\x30\60{$bZrah}\15\xa\x20\x20\40\x20\40\40\x20\40{$ZiLKm}\342\236\xa4{$bZrah}\40\64\56\x20\x20\x28\116\x45\x57\x29\40\70\107\x42\x20\65\x20\110\141\x72\151\40\40\x20\x9\x7c\40{$ZiLKm}\x52\x70\56\61\63\60\60\x30{$bZrah}\15\xa\xd\xa\x20\x20\40\40\x20\x20\x20\40{$ZiLKm}\xe2\236\244{$bZrah}\x20\x35\x2e\40\x20\x28\x4e\x45\x57\x29\x20\x31\60\x47\102\x20\x33\60\40\110\141\x72\151\x20\x9\x7c\x20{$ZiLKm}\x52\160\x2e\61\x38\x30\60\x30{$bZrah}\15\xa\x20\x20\40\x20\40\x20\40\x20{$ZiLKm}\342\236\xa4{$bZrah}\40\x36\56\x20\x20\50\x4e\x45\x57\x29\40\x31\60\x47\102\x20\67\40\110\141\x72\151\x20\x20\11\174\x20{$ZiLKm}\122\x70\56\61\60\x30\x30\60{$bZrah}\xd\12\x20\x20\x20\40\x20\x20\x20\x20{$ZiLKm}\342\236\244{$bZrah}\x20\x37\56\x20\x20\50\x4e\105\127\x29\40\x39\x47\102\40\x35\40\110\x61\x72\151\40\x20\x20\11\174\40{$ZiLKm}\122\160\56\x31\x30\60\60\x30{$bZrah}\15\12\40\x20\40\40\x20\40\x20\40{$ZiLKm}\xe2\236\xa4{$bZrah}\x20\x38\x2e\x20\x20\x28\x4e\x45\127\51\40\62\107\x42\x20\61\x20\x48\x61\162\x69\40\x20\x20\x9\x7c\x20{$ZiLKm}\122\160\x2e\x34\60\60\x30{$bZrah}\15\12\xd\xa\x20\40\40\40\40\40\40\40{$ZiLKm}\342\236\244{$bZrah}\x20\x39\56\x20\40\50\116\105\x57\x29\40\66\107\x42\40\63\x20\110\x61\162\x69\x20\40\x20\x9\174\x20{$ZiLKm}\122\x70\x2e\61\60\60\60\x30{$bZrah}\xd\xa\x20\x20\40\x20\x20\40\x20\40{$ZiLKm}\xe2\236\xa4{$bZrah}\40\61\60\x2e\40\50\x4e\x45\127\x29\x20\x36\107\x42\x20\x33\40\110\141\x72\x69\x20\x20\x20\x9\174\40{$ZiLKm}\122\160\x2e\x31\x30\60\60\x30{$bZrah}\15\xa\40\x20\40\x20\40\x20\x20\x20{$ZiLKm}\342\x9e\244{$bZrah}\x20\61\x31\x2e\x20\50\x4e\105\x57\x29\40\x36\107\102\x20\65\40\x48\141\162\x69\x20\x20\40\x9\174\40{$ZiLKm}\122\160\56\x31\60\x30\60\x30{$bZrah}\xd\12\40\x20\x20\40\x20\40\x20\x20{$ZiLKm}\342\236\xa4{$bZrah}\40\61\x32\56\x20\50\x4e\x45\127\x29\x20\x36\x47\102\x20\65\x20\110\x61\162\x69\x20\x20\x20\11\174\x20{$ZiLKm}\122\x70\x2e\61\60\60\60\60{$bZrah}\xd\12\x20\40\40\40\x20\40\40\x20{$ZiLKm}\342\x9e\xa4{$bZrah}\40\61\x33\x2e\x20\50\116\105\x57\x29\x20\x36\107\102\x20\65\40\x48\x61\x72\x69\40\40\x20\11\174\40{$ZiLKm}\122\160\x2e\x31\x30\60\x30\60{$bZrah}\15\xa\xd\12\x20\40\40\40\x20\x20\40\x20{$ZiLKm}\xe2\236\244{$bZrah}\x20\61\x34\x2e\x20\x28\116\x45\x57\x29\40\62\x35\107\102\x20\x32\x30\x20\x48\141\162\151\40\x9\174\x20{$ZiLKm}\122\x70\x2e\x32\65\60\x30\60{$bZrah}\15\12\x20\x20\x20\x20\x20\x20\40\40{$ZiLKm}\342\x9e\244{$bZrah}\40\x31\x35\x2e\x20\50\116\x45\x57\51\40\62\65\x47\x42\x20\61\64\40\110\141\x72\x69\40\11\174\40{$ZiLKm}\122\160\x2e\62\65\x30\60\60{$bZrah}\xd\xa\x20\40\x20\40\40\40\40\40{$ZiLKm}\xe2\236\xa4{$bZrah}\40\61\66\x2e\40\50\x4e\x45\x57\51\40\62\x35\x47\x42\40\x33\x30\40\110\141\162\151\40\11\x7c\40{$ZiLKm}\x52\x70\x2e\x33\60\x30\x30\x30{$bZrah}\xd\12\40\x20\x20\40\x20\40\40\40{$ZiLKm}\xe2\x9e\xa4{$bZrah}\40\x31\x37\56\40\x28\116\x45\x57\x29\x20\62\x35\107\102\x20\x33\x30\x20\110\x61\162\151\40\x9\174\x20{$ZiLKm}\122\x70\x2e\63\60\60\60\60{$bZrah}\xd\xa\40\40\x20\x20\40\40\40\40{$ZiLKm}\xe2\x9e\xa4{$bZrah}\x20\x31\x38\56\40\50\x4e\x45\x57\x29\40\x32\65\x47\102\40\x33\60\40\110\141\162\151\x20\11\174\x20{$ZiLKm}\x52\160\56\x33\x30\60\60\60{$bZrah}\xd\12\40\40\40\x20\x20\40\x20\40{$ZiLKm}\342\236\xa4{$bZrah}\x20\x31\x39\x2e\40\x28\x4e\x45\127\51\x20\62\65\x47\x42\x20\63\x30\x20\x48\141\162\151\40\11\x7c\40{$ZiLKm}\x52\160\56\x33\x30\x30\x30\x30{$bZrah}\xd\12\x20\40\40\x20\40\40\40\x20{$ZiLKm}\xe2\x9e\xa4{$bZrah}\x20\x32\x30\x2e\40\x28\x4e\105\x57\x29\40\62\65\107\102\40\x33\x30\40\x48\x61\162\x69\40\11\174\40{$ZiLKm}\x52\160\x2e\63\60\x30\60\60{$bZrah}\xd\xa\x20\x20\40\40\40\x20\x20\x20{$ZiLKm}\xe2\236\xa4{$bZrah}\40\x32\x31\x2e\40\x28\x4e\105\x57\x29\40\x32\x35\107\102\40\62\x30\40\110\141\162\151\40\11\174\x20{$ZiLKm}\x52\160\56\62\x35\x30\x30\x30{$bZrah}\xd\xa\x20\40\x20\40\40\40\40\x20{$ZiLKm}\xe2\236\244{$bZrah}\40\x32\x32\56\40\50\116\105\127\x29\40\x32\x35\107\102\40\x33\x30\40\110\141\162\x69\40\x9\x7c\x20{$ZiLKm}\x52\x70\56\x33\60\60\60\x30{$bZrah}\xd\xa\x20\40\x20\x20\x20\x20\40\40{$ZiLKm}\342\236\xa4{$bZrah}\x20\x32\x33\56\x20\50\116\105\127\x29\40\62\60\107\x42\40\61\64\40\110\141\x72\151\40\11\x7c\x20{$ZiLKm}\x52\160\56\x31\65\60\x30\60{$bZrah}\xd\12\x20\x20\40\x20\x20\40\40\x20{$ZiLKm}\342\x9e\244{$bZrah}\x20\x32\x34\56\x20\x28\x4e\105\127\51\40\x32\65\x47\102\x20\x32\60\40\x48\x61\x72\x69\x20\x9\x7c\40{$ZiLKm}\122\x70\x2e\x32\65\x30\x30\60{$bZrah}\xd\xa\40\x20\40\x20\x20\x20\40\x20{$ZiLKm}\xe2\236\xa4{$bZrah}\x20\62\65\56\40\x28\116\105\x57\x29\x20\62\x35\x47\102\40\x33\60\40\110\141\162\151\40\11\174\40{$ZiLKm}\122\160\x2e\x32\x39\x30\x30\60{$bZrah}\x20\xd\12\40\40\x20\x20\40\x20\x20\x20{$ZiLKm}\342\x9e\244{$bZrah}\40\x32\x36\x2e\x20\x28\116\105\127\51\x20\x32\x35\107\x42\40\63\x30\40\x48\141\162\151\x20\x9\174\40{$ZiLKm}\122\x70\x2e\x32\65\x30\60\x30{$bZrah}\40{$Q1yRv}\x28\x44\151\163\153\157\x6e\x29{$bZrah}\x20\15\12\xd\12\15\xa\xd\12\x20\x20\40\x20\xa";
        goto nwa1I;
        Pba5d:
        echo "\40\x9\x49\x50\40\x41\x64\x64\x72\145\x73\163\72\x20{$ZiLKm}{$goQaj}{$bZrah}\xa";
        goto GggF5;
        C75CO:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYHOST, 0);
        goto GBuJq;
        dVZoS:
        Ck09D:
        goto P0M3v;
        LcdL0:
        $wSkBj = $A5zwr["\x70\162\157\144\x75\x63\x74"]["\160\162\157\x64\165\143\x74\104\x65\163\x63\x72\151\x70\x74\x69\x6f\x6e"];
        goto zkQlh;
        OONZN:
        curl_setopt($fDow0, CURLOPT_CUSTOMREQUEST, "\x50\117\123\x54");
        goto J5IOB;
        DOwyD:
        goto r6Xfg;
        goto fknFY;
        lco_i:
        if ($X_Clp == "\62\x33") {
            goto CumNv;
        }
        goto j6gz1;
        li0fC:
        goto r6Xfg;
        goto hkOkc;
        oL4PH:
        ElfDu:
        goto Ld6tf;
        hicYb:
        if ($X_Clp == "\x32\x35") {
            goto QxHRA;
        }
        goto HMtXu;
        m5iXy:
        fZExU:
        goto ry1R6;
        jHUG5:
        $ZiLKm = "\33\x5b\x33\x33\155";
        goto OKFrT;
        YxacP:
        goto r6Xfg;
        goto TbrpH;
        cigb0:
        $TRQtM = $A5zwr["\160\162\157\x64\x75\143\164"]["\x70\162\157\144\x75\x63\164\x49\144"];
        goto ssPlp;
        ER5S3:
        if ($vIoSS == 02) {
            goto JQ0eD;
        }
        goto A3z0d;
        ZM90K:
        if ($X_Clp == "\x34") {
            goto tBv4E;
        }
        goto wdRSL;
        QKUsi:
        JYniT:
        goto weYoD;
        J829j:
        echo "\40\33\133\63\x34\155\111\x4e\x46\x4f\x1b\133\x30\x6d\72\x20\33\133\x39\x32\155\120\x65\155\142\145\x6c\x69\141\156\x20\x70\141\x6b\145\164\40\142\x65\162\150\141\163\151\x6c\56\x1b\x5b\x30\x6d\12\12";
        goto kwFSt;
        J0DZj:
        echo "\x20\33\x5b\x33\64\155\111\x4e\x46\x4f\33\x5b\x30\x6d\72\40{$xnOeC}\x20\55\x20\122\x70\56{$s3S3h}\12";
        goto zcvx7;
        X3AuD:
        OQFok:
        goto V8AqP;
        lT0vW:
        $QKbpo = trim(fgets(STDIN));
        goto McdIx;
        rpNsO:
        curl_setopt($fDow0, CURLOPT_SSL_VERIFYHOST, 0);
        goto MXykv;
        CGcNF:
        oioDe:
        goto bGQS0;
        cSwxr:
        error_reporting(0);
        goto f6Rzz;
        DmTbS:
        $s3S3h = $A5zwr["\160\162\x6f\x64\x75\x63\x74"]["\x70\162\x6f\x64\165\143\x74\x50\x72\x69\x63\145"];
        goto YzdYI;
        bcxYS:
        MwUJG:
        goto SY2rW;
        qcP0Z:
        $fDow0 = curl_init();
        goto Kj8UC;
        v8CpJ:
        echo "\x20\x1b\x5b\63\64\155\x49\x4e\x46\x4f\33\x5b\x30\x6d\72\x20\157\164\160\40\x20\40\x20\x20\40\40\40\x20\x20\x20\x3a\40";
        goto zn8j1;
        C8vkH:
        if ($X_Clp == "\x38") {
            goto cZOV7;
        }
        goto M0I0O;
        gZCR3:
        $pTiib = array("\x61\160\160\55\x76\x65\162\163\x69\157\156\x3a\x20\64\x2e\x32\x2e\61", "\103\x6f\156\164\x65\156\164\x2d\124\171\x70\x65\72\x20\141\x70\x70\x6c\x69\x63\x61\x74\151\157\x6e\x2f\x6a\x73\157\x6e\x3b\40\143\x68\141\162\163\145\x74\75\x55\124\x46\x2d\70", "\x48\157\163\x74\x3a\x20\142\x69\x6d\x61\x70\154\x75\x73\56\164\162\x69\x2e\143\x6f\56\x69\x64", "\x43\x6f\x6e\x6e\x65\143\x74\x69\x6f\156\72\40\113\145\145\160\x2d\101\x6c\x69\166\145", "\125\163\145\162\55\101\x67\x65\x6e\164\72\40\157\x6b\150\x74\x74\x70\57\64\56\71\x2e\x30");
        goto kcjw1;
        pFwHL:
        echo "\xa\xa\40\11\124\x6f\x6f\x6c\x73\x20\x42\151\155\141\53\x20\166\61\x2e\60\x20\124\x65\155\142\141\153\40\160\141\x63\x6b\141\x67\x65\12";
        goto Pba5d;
        S0Caj:
        xG2_a:
        goto kE7N7;
        PQ0Qk:
        if ($X_Clp == "\x31\64") {
            goto CdqY0;
        }
        goto vqBOV;
        Kkooh:
        $vZcAK = "\x7b\x22\151\155\145\151\42\72\x22\127\x65\142\x53\x65\x6c\x66\x63\141\162\x65\42\54\x22\154\141\x6e\147\165\141\x67\x65\x22\x3a\x22\x22\x2c\42\143\141\x6c\154\x50\x6c\141\x6e\x22\x3a\x22\42\x2c\x22\155\x73\151\x73\144\x6e\x22\72\x22\42\x2c\42\x73\145\143\162\145\x74\x4b\x65\171\42\72\x22\x22\x2c\42\x73\165\x62\163\143\162\151\142\145\x72\x54\x79\x70\x65\42\x3a\x22\42\54\x22\x70\x72\x6f\144\x75\x63\164\111\144\42\72\42" . $Zh3ZY . "\x22\x7d";
        goto oHyME;
        FBDp3:
        if (!($Lru7V == null)) {
            goto ElfDu;
        }
        goto IrBKj;
        C7dtD:
        tjIFV:
        goto H1ewt;
        h9Vdj:
        hK1uz:
        goto YbAd4;
        vOa7J:
        $vZcAK = "\x7b\42\x69\x6d\145\151\42\72\x22\127\x65\x62\x53\x65\154\146\143\x61\162\145\x22\x2c\x22\x6c\141\x6e\x67\x75\x61\147\x65\42\x3a\42\x22\54\42\143\141\x6c\x6c\120\x6c\x61\156\x22\72\x22\x22\54\42\x6d\163\151\x73\x64\156\x22\72\x22\x22\x2c\x22\163\145\x63\162\145\164\113\x65\171\42\72\x22\42\54\42\x73\165\x62\x73\143\x72\151\x62\x65\x72\124\x79\160\x65\x22\72\x22\42\x2c\x22\160\x72\157\144\x75\143\x74\x49\x64\x22\x3a\x22" . $Q5lkT . "\x22\x7d";
        goto ny21H;
        Xc8KL:
        curl_setopt($fDow0, CURLOPT_POSTFIELDS, $vZcAK);
        goto VK8b7;
        IOKo2:
        EsXiD:
        goto yUINd;
        J5IOB:
        curl_setopt($fDow0, CURLOPT_POSTFIELDS, $vZcAK);
        goto uDLnp;
        yIVSo:
        curl_setopt($s_B0W, CURLOPT_SSL_VERIFYHOST, 0);
        goto mVMMO;
        GggF5:
        echo "\x20\11\101\165\164\x68\157\162\x20\40\40\40\72\40{$ZiLKm}\111\x64\144\141\156\x74\x20\x49\x44{$bZrah}\xa\xa";
        goto P3A09;
        i4mTa:
        $A5zwr = json_decode($PBsM7, true);
        goto vLdbD;
        TbsiA:
        $X_Clp = trim(fgets(STDIN));
        goto wX05e;
        Wa3KF:
        $Zh3ZY = "\x32\x35\64\66\61";
        goto Lf_F3;
        SemO3:
        if ($X_Clp == "\67") {
            goto WIO37;
        }
        goto C8vkH;
        N0WAa:
        echo "\40\x1b\133\x33\x34\155\111\116\106\x4f\x1b\x5b\60\155\x3a\x20\120\x68\157\156\x65\40\x20\x20\x20\72\40{$tC6RW}\12\12";
        goto cROgd;
        wGlon:
        if ($P1SYq) {
            goto JzBWF;
        }
        goto K6Eje;
        ze4Ij:
        $Zh3ZY = "\x32\x35\62\x36\x37";
        goto gOVw1;
        gas3N:
        goto zA4v3;
        goto p0qIQ;
        XRlih:
        curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, 1);
        goto Sosmz;
        vsXL6:
        if ($F9sV1 == "\171") {
            goto OQFok;
        }
        goto d1eNI;
        eZQir:
        goto TKy7_;
        goto dVZoS;
        fwBWy:
        goto r6Xfg;
        goto evWKr;
        uvYd6:
        echo "\40\x9\120\x72\x6f\166\151\144\x65\x72\x20\72\x20\x42\151\x6d\x61\x2b\x20\x28\40{$ZiLKm}\x54\150\x72\x65\x65{$bZrah}\x20\51\12";
        goto UHTqN;
        gIRGX:
        $Tjllh = trim(fgets(STDIN));
        goto i64EH;
        A6qnO:
        bYv28:
        goto gEJZU;
        MXykv:
        curl_setopt($fDow0, CURLOPT_CUSTOMREQUEST, "\x50\x4f\x53\124");
        goto w0P3_;
        JFGie:
        curl_setopt($fDow0, CURLOPT_URL, "\x68\x74\164\x70\x73\x3a\57\57\x62\151\x6d\141\x70\x6c\165\163\x2e\164\x72\x69\x2e\x63\157\x2e\151\144\x2f\x61\160\151\57\166\x31\57\x70\165\162\143\150\141\163\145\x2f\x70\x75\x72\143\x68\x61\163\x65\55\x70\162\157\144\x75\x63\x74");
        goto iyTuQ;
        P0M3v:
        goto kTvLi;
        goto MyZWC;
        scJ4Y:
        $fDow0 = curl_init();
        goto tpmbh;
        YPshr:
        goto r6Xfg;
        goto A6qnO;
        ggD0U:
        if ($X_Clp == "\62\x32") {
            goto semmz;
        }
        goto lco_i;
        NgXSf:
        goto vdQhX;
        goto lj1o6;
        a3HYk:
        $Zh3ZY = "\62\65\x35\64\x36";
        goto QdoWr;
        bN7XD:
        $VOjs5 = array();
        goto hW3P9;
        lm59B:
        echo "\12\xa\11\x57\145\x6c\x63\157\x6d\x65\x20\164\157\40{$ZiLKm}\102\151\x6d\141\x2b\40\x43\114\111\x20\x54\x65\x6d\x62\141\x6b\40\120\x61\x63\x6b\x61\x67\x65{$bZrah}\xa";
        goto uvYd6;
        fbbo5:
        exit("\x20{$ZiLKm}\342\236\244{$bZrah}\x20\120\151\154\151\x68\x20\155\145\156\165\x20\x79\x61\x6e\147\40\x64\x69\40\151\x6e\x67\x69\x6e\153\x61\156\x2e\xa");
        goto cGyfH;
        bkJjj:
        $Zh3ZY = "\x32\x33\x31\66\60";
        goto fwBWy;
        FN9CD:
        echo "\40\x20\x20\x20{$ZiLKm}\xe2\x9e\244{$bZrah}\40\60\61\x2e\x20{$ZiLKm}\x43\150\x65\x63\x6b\40\x44\x65\164\141\x69\x6c\x73{$bZrah}\xa";
        goto nKY8i;
        JPZZ6:
        $Zh3ZY = "\62\x34\x31\66\x33";
        goto fHRnH;
        VZ_V9:
        curl_setopt($fDow0, CURLOPT_HTTPHEADER, $pTiib);
        goto eRchC;
        Gwhcn:
        if ($X_Clp == "\x31\67") {
            goto qOOot;
        }
        goto sJ_AT;
        Fi8Z0:
        echo "\x20\x1b\x5b\63\64\x6d\x49\x4e\106\x4f\x1b\x5b\x30\155\x3a\40{$xnOeC}\x20\x2d\x20\122\x70\56{$s3S3h}\xa";
        goto fSI6s;
        NCofE:
        sleep(3);
        goto Q7Zo5;
        qQ96K:
        UuWJs:
        goto GBH7S;
        w0P3_:
        curl_setopt($fDow0, CURLOPT_POSTFIELDS, $vZcAK);
        goto PmhAs;
        JQCvD:
        curl_setopt($fDow0, CURLOPT_HTTPHEADER, $pTiib);
        goto kAbVe;
        Ov6Z8:
        curl_setopt($s_B0W, CURLOPT_SSL_VERIFYPEER, 0);
        goto yIVSo;
        kF8cu:
        $Zh3ZY = "\x32\x33\x39\x38\62";
        goto Y4eW4;
        emt5V:
        tBv4E:
        goto P_Boh;
        fSI6s:
        echo "\40\33\133\x33\x34\155\x49\116\x46\117\33\x5b\60\x6d\72\40" . $wSkBj . "\12\xa";
        goto SFi0h;
        wF4SP:
        curl_setopt($fDow0, CURLOPT_URL, "\150\x74\164\x70\x73\x3a\57\x2f\x62\x69\x6d\141\x70\154\x75\x73\x2e\164\162\x69\x2e\143\x6f\56\x69\144\57\141\x70\151\x2f\x76\x31\x2f\x6c\157\x67\x69\x6e\x2f\154\x6f\x67\x69\156\55\x77\151\x74\x68\55\157\x74\160");
        goto ONblu;
        ZGG2L:
        curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, 1);
        goto z95Zq;
        JTRdz:
        curl_setopt($fDow0, CURLOPT_HTTPHEADER, $pTiib);
        goto ZGG2L;
        TbrpH:
        RpGvN:
        goto Wa3KF;
        Jsxu1:
        U3eQE:
        goto mVX95;
        dloAV:
        $Zh3ZY = "\62\x35\66\67\66";
        goto jqdgk;
        F6hsK:
        $Zh3ZY = "\62\65\64\x36\60";
        goto YxacP;
        sJ_AT:
        if ($X_Clp == "\x31\x38") {
            goto bYv28;
        }
        goto T2dWz;
        eRchC:
        curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, 1);
        goto r48bD;
        Y4eW4:
        goto r6Xfg;
        goto Piin3;
        n0Zm8:
        goto r6Xfg;
        goto kysOi;
        K6Eje:
        JzBWF:
        goto My7jY;
        THqii:
        echo "\12\x20\x1b\133\63\64\x6d\x49\116\x46\x4f\33\133\x30\155\72\40\x44\x65\163\x63\162\151\160\x74\151\x6f\x6e\x20\x70\x61\x6b\x65\x74\56\12";
        goto J0DZj;
        yQSkN:
        sleep(3);
        goto qUR_S;
        kAbVe:
        curl_setopt($fDow0, CURLOPT_RETURNTRANSFER, 1);
        goto Qqh08;
        kwFSt:
        GlA9L:
        goto NCofE;
        weYoD:
    }
}
error_reporting(E_ERROR);

use RBlgw\RbFjj;
use rbLgw\fZIde;
use RBLgw\AdZtb;

if ($argv[1] == "\55\55\164\x68\162\145\145") {
    goto jId4d;
}
if ($argv[1] == "\55\55\x68\145\154\x70") {
    goto Lk2yD;
}
if (isset($argv[0])) {
    goto MImZv;
}
goto n24kS;
jId4d:
rBFjj::PwGL2();
goto n24kS;
Lk2yD:
echo "\40\33\x5b\63\x34\155\111\x4e\106\117\x1b\x5b\x30\x6d\x3a\40\55\55\164\x68\x72\x65\x65\x20\11\106\x6f\x72\x20\162\x75\156\156\151\x6e\x67\x20\x74\157\157\x6c\163\40\x74\145\x6d\x62\141\153\40\160\141\143\153\141\x67\x65\x20\124\150\x72\x65\145\56";
goto n24kS;
MImZv:
$ZiLKm = "\33\x5b\x33\x33\155";
$bZrah = "\x1b\x5b\x30\155";
$Q1yRv = "\33\133\x39\x32\x6d";
echo "\x20\x1b\133\x33\x34\155\111\116\106\x4f\33\x5b\x30\x6d\x3a\x20\x57\x65\x6c\x63\x6f\155\x65\x20\x74\157\40\x54\x68\162\145\145\x20\120\162\157\166\151\x64\x65\162\xa";
echo "\x20\x1b\x5b\63\x34\x6d\x49\116\106\117\33\133\x30\x6d\x3a\40\105\x78\x61\x6d\x70\x6c\145\72\40\x70\150\x70\40\155\x61\151\x6e\x2e\x70\150\x70\x20\55\x2d\x68\x65\x6c\160\xa";
echo "\40\x1b\133\x33\64\155\111\x4e\106\x4f\x1b\133\x30\155\72\x20\x47\145\164\x20\x6c\x69\143\145\156\163\151\40\x66\157\x72\40\141\143\164\x69\x76\141\163\151\40\x63\157\x6e\x74\141\143\x74\40\x61\144\x6d\x69\156\40\x28\40{$ZiLKm}\60\x38\x39\65\x33\67\65\x31\x33\66\x33\x31\x31{$bZrah}\x20\51\12";
n24kS: