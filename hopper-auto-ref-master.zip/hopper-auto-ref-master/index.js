const fetch = require('node-fetch');
const cheerio = require('cheerio');
const { faker } = require('@faker-js/faker');
const moment = require('moment');
const readlineSync = require('readline-sync');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const SMSActivate = require('./lib/sms-activate/index');
const NodeCache = require('node-cache');
const myCache = new NodeCache();
const colors = require("./lib/colors");
const zlib = require('zlib');

require('dotenv').config()


const getEmailRandom = (email, domain) => new Promise((resolve, reject) => {
    fetch(`https://generator.email/`, {
        method: "get",
        headers: {
            accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3",
            "accept-encoding": "gzip, deflate, br"
        }
    })
        .then(res => res.text())
        .then(text => {
            const $ = cheerio.load(text);
            const result = [];
            $('.e7m.tt-suggestions').find('div > p').each(function (index, element) {
                result.push($(element).text());
            });
            resolve(result);
        })
        .catch(err => reject(err));
});


const fakeName = () => {
    const randomName = faker.name.findName().toLowerCase();
    const random1 = faker.word.adjective().toLowerCase();
    const random2 = faker.word.adverb().toLowerCase();
    const name = random1 + randomName;
    const result = {
        firstName: random1.replace(/\s/g, ""),
        lastName: randomName.replace(/\s/g, ""),
        name: name.replace(/\s/g, "")
    }
    return result
};


const randstr = length => {
    var text = "";
    var possible =
        "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";

    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
};

const functionGetLink = (email, domain) => new Promise((resolve, reject) => {
    fetch(`https://generator.email/${domain}/${email}`, {
        method: "get",
        headers: {
            accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3",
            "accept-encoding": "gzip, deflate, br",
            cookie: `_ga=GA1.2.659238676.1567004853; _gid=GA1.2.273162863.1569757277; embx=%5B%22${email}%40${domain}%22%2C%22hcycl%40nongzaa.tk%22%5D; _gat=1; io=io=tIcarRGNgwqgtn40O${randstr(3)}; surl=${domain}%2F${email}`,
            "upgrade-insecure-requests": 1,
            "user-agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36"
        }
    })
        .then(res => res.text())
        .then(text => {
            const $ = cheerio.load(text);
            const src = $("#email-table > div.e7m.row.list-group-item > div.e7m.col-md-12.ma1 > div.e7m.mess_bodiyy > p:nth-child(4) > span").text()
            resolve(src);
        })
        .catch(err => reject(err));
});

const getRefferalId = (refferalLink) => new Promise((resolve, reject) => {
    fetch(refferalLink, {
        method: 'GET',
        headers: {
            'Host': 'go.hopper.com',
            'Connection': 'close',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 7.1.1; Custom) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Dest': 'document',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9'
        },
        redirect: 'manual'
    })
        .then(res => res)
        .then(res => {

            const location = res.headers.raw()['location']

            resolve(location[0].split('target%2F')[1].split('&')[0])
        })
        .catch(err => reject(err));
});

const getDetailReff = (userId, refferalId) => new Promise((resolve, reject) => {
    fetch('https://mobile-api.hopper.com/api/v2/target/' + refferalId, {
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': 'H4sIAAAAAAAAAJ13Vw+1ynLlf/le8T3kdN7IOWdGI4scNmmT2Vf+78O1ZY3mzRqEhOjuquruCqvWP/90ZTXt3f78+fuff46tWpXyz99/CqIkygIi/kFnFP0PDKLIf2R1UfwDhsqqyouaygviz7/9KauzK6r/lCCKui5pCqbhkkAKAn5ns2X5L2Xz+Fc7L0u1/jXOx7Rn3XR21fXXMmTPu+ys1q2bp3/ZP7PhqF4J/C/yL+Sdyo9uKM1jzKv1z98wTFAI+R//8W9/lrWqq7Waimr7l9QwF9nwL7Fq+vfAe8WKY/3X7HukP4xovgN7N1bpPP1rDTNWa1dkoFld/57M6+fPq2/LzqpU9mp81f2vf/7f33c5l61r927wVbLt2V79y96eNf/5eZW+Y+PyLkMgBPkHhP0DonwYfXf6N4T+BRP4O/Q3BP3LhPffOr3/0vLHmLfdrYr37v+8R/p/jbpV817I/9gm7MPI3xj1N4T8hcLU/6dNvqqzY9j1bvr8DwzD70n/AdM+Ar223vcvCIL+p4b/97/9qe43GF6N0/7e+B8Z2xTmvx81zBG0JsxWB2K0r2yviuM1pTF8uaRG0VvbDRFGDxA1jT+fYfZBEJ1S8RPh6uCxIFLKVKMa8Iwv+6mfw1pwaeo6FQj2IYbPy7gC572JCqVi652c/JrIzahzNtkzJGCWbzDrnxAXnt+n2cQYw/HZ8W1MO+OFQi7VGJQPpw1EcinEBNHqR+dAWpu6jdHcaLwMFAN/wqBp4KDB6Txrm/Wz4Q4XenfgQnIbvB1JhIF+6qTRE/PdWu7wHvQJgJ8BS6G+ON9o8IJQw1PqkWTE8/AnUpOUZMoJ89TsK1gh5gGKID5m5//YHsaxavTFwo/7OwJCloVdIbwf2rS6p/VzSpg/G69gxrfKXZHNCHM3WQ6otaAzqp9Xkxbe4um3kmqkCJggf34CuKFetFWm2gfAxzIVV3NWekbztfKENZB2TnxcHUknLUulaGKDuQBhkLzxZvbxiZ1q7AN8db0B5LTbo1B/PB33FOaLAyxxyL51YR5VYQWeLnFGL3yzAONVPhZ4ZBllhrDrHSU2JJC4sT5aNpdf7VX73TNTgivmQ3HGGtpbkfiBJB64Rc9SSyqPlqKqZCy+8Ft34A7P7+UxsUJkA+R8RglFYEamJjU27rxRdeZ8fLsZwAwtqc8eVQ/P3Zevaj5567lAwz6Sr8Gq6uWXTLgLsQuUklDhSfy4jb/gF3vLoWcY4v6gPMqMQwHoan9j8uuF0aoG2LnvIlifaD8ZmPpywTnd7gA9YMizIQEtxBS4vxykNkKCvU883irMKOB9dV4CqcJu0t/KKr/qHm6QIOsq5t7MsFtPyN1TDaw5X5r6LCarEK8kIHg+DxNLn2kDzWYsW8jj/N6DmLEc7e6+tyng7g95jFZwx1Jwj+GSWwT+qE2NbVf1ou9HqEUf3pT5tZesLZPTJLBFy1EX+hhH0W08s+ggjJtMcgKwimxpt0Y+3n5IVVwW4zSTB55uqAUC5FmGmxyZYbDD86iaIFzCYuJbKgHlmV6UTbxy2qULOtSm1zTMIbN1dtcBh4xIgf29P/EqtaLT/3raia80dYBf80uUFCD0xW8wP0yFLbJTa1suxawSLmlAob1j/TBXr2l9d4ek8JKBMVEFsfZ2X4LlrPS2r8rRyjLC4yhFDZ272qAjff3NG3Y8LreeDWltZ5Xe6Eqg26kvDmx2R0HSoRKmZmRWuOXDNampCJ0X4Pp8bs1agIIokGaSemseeFNsyixnRPd62meT+nxnjqrFJYgtBZSPqu4ei73/432KNSkuU4NxuOpKEH4E3btM3+t0yDYu57mChp8VGxl889hJLjFe8ttAWZMGIa6zC97n16s4ikwkb0ViZ8I6u8T2qTedJuRmd1fcTodffYAZ/U3ldXAsOINwGrjqj7FFv7ioJEkKh9+0WdG8cxHJG+2Dul8XoER+uHIoI8t4shpAiaeqGIfUPjejMz09YDXjkzdTWygQyOTYLTXYPdnGSeLh+GL7dX+9HzbbaH20PQ/7K8ikkNWSaiir9sCgEwMylMbYGikTkYDDwWVhX/8CNcm8W5lN7Bi5mejsu8Ifo7Jo+PnTMnbfGDunUIQm2/DcAR6EuQJcf6qzXTNa0ab5wFTEzPvP0WzLVyeimdJDYZkzE9liNxa2duSV66zZnjwsFPJq04cDt641QTN0WteCGtDEcGY6rXOHsVmje283wtSAKR6dFG0LbWEbL9njDbsBozCvrAe3TfNT4JBkCdaZEmFXoSb9ZOnOTUl6YD5ZZso2VHSGqhO4FDO/Q/tWVDhj5g1slhv51Y7203YNC9y+376ZupmpQ+4sYa+jpGymwUxKoOBro4IapLjDDnk3VCWNCjDcpaFPr9B2edbY8Ok2lflan8l1J+eOKq0sAwfWhwR5hBy5tKBPIQXI84KRk57VQyZ3bmcLfD1sBvN54Slr7gNQgTNoTPPziIo6BZ5K8U6EenLG1KAKzYopeicW8T5qUKykoJ2kcw362VrKQa0VN489K0g/wvzkyPL9E36gnS2WrDHgcMZZy7h5G2Ev8zYUe6uRuxHBbM8G83eaz0Y1IknTTS6s7oYGfjPMuy36h0tbqWmRD+0kNr4lbO3rlDclVmfl2O9Sc5tAZObnF/sMKk+2dmvSeet+QSv3oaRWFQ9mDr1bvr8BkXLkOs3NhxFidfbDO5akcrojn104CzxLhcbp6/so5/MRAPnTTtAi3uHOTcEqfNVKKTj2KCn0cMuCb2WOXYnDQdAW31XhEDqgpzfEsOorhSog75u7B28NYixTNNEmdd0R4MQOV5uudaYgTS4+L4rn5vK0t6Qc91ek7XWt81QAsbwCTDQybXa0BntXu2OK/2Z5nk+Viq+p9GthNjnGoaSNQt9HE0S4G4m8cmq7GLpX+VxGcR1c3NY0Fqq6NkcV7XJ3nnl9Oo8PN5zOfKytqWdbgBo5LJ0T+hVTWMRI1oUTvuUemwPl5KtJK8er1JKk8lszHM/5WnWXal7+bTYsgeeSsvQnEIveLKPYkD3FXhJK/v4kihY36di+xO+YyPH69Aaqj43xLRHgTI4at+NHa+xxK2dwF+phm4SRsaR57n3yyFf4yxOgibG4SwcF8wXKshPxJJDaj88OzaxvRuCs0heix0saX0T0fsikNFDMWIKl2VrYby5xBuRjsNJP+7IhOYW+Dt6AucMRRp/y0lwzH5tYxee3wXAI4yJwGPVDCybInvgItwgwMFaiSDntVlAYOFZJnBdA0VDTmt9dxJc6tyuqkXfM94IlTNDurg6YuxMOKaoDQAPL9S7KJ4b6tzhaF6ygPZgxTIo+wxjGFC2sTRFHFJGE4QdhouQ7xuuQ4Ys37gVix/NDt/dbBxYnfWY5DfJsXsv0e37oQHHtqYwCtnOgDS28weTsjymvONYQXw3mf6tm9b8gbS/V9z6XCZ/sFaF0FoIoEpq9g4s+8mGHlYwj3l12Ak60veQ84hNO3/URhIIVKE8Cgb6O5nuw3wRhGtywcAESgMujUf5pDd1UXnw6Al7mj9LXLIIV5mEUIMq5aokl4v47yBnS/5Lp6FbQ+XXHB0nI7Os+Br/h7eVqTVpGBFumV3KniT8OGcFnbi6HwRQTnQ4RuaDQkcCFbFerUqyPfZqIKEeBeisixcRZzizo32KrWpzpkuJ7hi/LKXul3U82Cb8efrHxuH8aHapIJAu/jfvm8M87O2Oe9QzbJ3/FGJeoE3u9z7dHnWxQKs7mkiJxuCtDe7FXLrnviMI4LWPSSl7yQZPPvjpZwIcYBdS6vCvMTY3xRdTsUK3jrFVz5Bo98I0iNoYmEaZzeoXeSnRkFhg7Tu2JcsnEV6AKX28CqZUbOc+5ysSx4V+YVY+k4UpbhjOfz9mi6uR1mRGuPxDBukapueyj+JTdMSdmhcY1tEvjYQH862RpHOE0LvWKcpXWAjNuI2j3Ss02ulMXSItZNh2YOqwD625jxphyvTj3+HmohcSuWwnKYN052pAshAy2n9exM4hGJSeDSvmy0e+/CEFMq30yCB1ehL+CxOOQj2nLU4AjR9jXEowAIrzmvo6L3yRE0rdx3AV7YomXImhjQKH1mzFpVRILH+ExtQqSKPD0ndWajZ0fru2ovtsaX2N6LB3k5stWdX7vxDMa8u6wQWJaJibTnjm+ziOaIEpOTdIxoszuj/fkaVJ0rFflvkf8dEZDlrMgOf6SavB3ynyNUyXtr96J8OzERm+mQwUR9ox9Gc4KwzOx+lWnxP1MSxVWxpWrO06VVDilYGrO50vPHkGXeUv7G5oGfhuTRiCrNU7OTZUqXsgVJcGlT7vH0yowDnuvQyl2l0G3yS9Bepxs6mtJhsn+KCDV+WfGfeCExMXjPV0XdvfGXGiJ2w9/L5C8RAetoGmPgdlZM1gEnJFpDPHiaz+G2iryIGtz4cphrfYrjNXvCwDwOnotQZI0kZoMooXKqq+lpRZhmzs/UqKQwPtgxpKefm16lY8/ILbffVsDWWIFEeGXW08AS1paWOQ3iMZlaSK7YjWWeY9/aK14PZGFL6YvK91DJiguFHj+aPFbXgh13O6qOjlym/WZzzGM4dx056VAI8je3gqGvJlQvvR9JI2qFY5VIwXXlIKXHpV8UejkESi5z60qH4nunOxnl3H1nrxJ+pLqkCGt4Di1LvGZDuA1EueCfte/IU1iIMAbZXhvj87w3NpGuzaNX/ZpgQggQUP+1TMpZGFeM3XUTUPW5r+lxw8wCE/AbLkRQE5T3l2FxD7ZnnQ3DImUVbipYpgeg/Ou+tg9CUzWTHlCxvFcMxFb8vLDPPipt4lYAtMyuUfmvID/jON8lB+nzgFiZ7JhGRZjwoJb0D+w6g7C72ZOYjKLV8ItSTYbU1sv73XpPIshXwY7bBg+mtf9OS6q7rc7z9iI8Czb4PYKkkaHWhVPCoS3dEkteC1GL3WV01dhUWBwijimBUMON6BtVzjblL3Mnhdv7OC+VI7PLFkVyKpCWe5sIuNY0PWGEytDLsSQmRFQ1Z2y6AeSLXAN+4rALAWJJ8BIf1t5oXRFJACia9VdSoWhuK4lCFToPTDO4IbnSFl+WE0ggS9iJBCfCOqqNRJfm7uMrTH/hLj/lbP+tvrnOgInaGUnHzGDhjJaZIgG+z5hX6qf1gr3eUQikn2IprojEzllcZazDEMZ6/TO8TM1d4SFq5fijqvbL/t95ihOAVZ7O2qzxQnzSHd4Z6uBjgBzmbj9OBZiLIaMueictxKcsZe3qtMu/ct5j9x92jq8rVzJtJx+JQguncVPPpW8KQXamj5CB3oYWMSBZch/PlNaE0KHOmV8iDtQ3X4l+YvlkMptJRpUTzV59tGKus8mP0YibzfgB3IgoskG9gqp7I5ZtHeLon08riaS+BndygQQ6GovxBtNiXZA5d74IRiaYtIBQkcLeaZx2DPkQMRkt9Dq0715mHpvo3jJsrww8QcR7cYhlFvntsHJ7hKQkeJy6gIMdxp+jrL7dNSkXk4pI+vbgC87+kGAtwkp41X+mhv8MiZMoba5bHKo4LmDPZVCxqf1mlEQ1lJSNWABPR3TIySkSNjKcjVB9BtTMMKBIEb/24xCjxb+LIRWnEAdYZiThjzwxa69aG6+AIy7ZkuQDQOqMLJi9fHDap8vv44BEGW0Mmt0sBYW2Eqg2qW2OhClLicawzsFjM12Fw7d2LgcYV+0r1NUHXbxn1nVL+ZD3EgvkYQRHCgR7esMteXWXCCi3QrfZl9SbnIk5Zx+lix1j4nChWpPO5dh4z+lfbpMJIGYpcUl6kfU/TshssFxqU6uAeHCA6Vvp8CfwI+j3/YM1Dnx2O3aSyFPbyuGjaY0P2miS5hYo92LgayDwy+fc2X+uwb9G1BOftZWbGvmUlUWUJPrxchtKLOON03wXkmxHRrQF4A3lbps/5tdz2MmV5P8WLFDwJfbNGQyh4gYQ59JRqPfWH8NiQA5vzr6L2e8hB3rHGSN2AudWmsKYJjkDjwOUbv7JWtyaREK3s/HJej2+qL2Gau2JsIJtSUSMCditmB24fnuUimHkod9uizFkZhj+ORvFEPcYpRLPhP17X3Xhsg+xAmETl3ZWvvYNXnlhxHbgMiq6NPq3S49a+DkgeBtc3N4k76AmCleNe9+kNAu+th4xdeHpkGQRe57aTveYhjmz3/8HwmG4iNSGAAA',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        }
    })
        .then(res => res.json())
        .then(res => {

            resolve(res.response.appTarget)
        })
        .catch(err => reject(err));
});

const trackingDelivery = (userId, urlTracking, hRequest, body = '') => new Promise((resolve, reject) => {
    fetch(urlTracking, {
        method: 'PUT',
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': hRequest,
            'Content-Type': 'application/json; charset=UTF-8',
            'Content-Length': '34',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        },
        body: JSON.stringify({ "trackingEntryPoint": body ? "deep_link" : body })
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

const registerUserId = (userId, phoneNumber, deviceId) => new Promise((resolve, reject) => {
    fetch('https://mobile-api.hopper.com/api/v2/registrations/sign_up_or_sign_in', {
        method: 'POST',
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': 'H4sIAAAAAAAAAJ13Vw+1ynLlf/le8T3kdN7IOWdGI4scNmmT2Vf+78O1ZY3mzRqEhOjuquruCqvWP/90ZTXt3f78+fuff46tWpXyz99/CqIkygIi/kFnFP0PDKLIf2R1UfwDhsqqyouaygviz7/9KauzK6r/lCCKui5pCqbhkkAKAn5ns2X5L2Xz+Fc7L0u1/jXOx7Rn3XR21fXXMmTPu+ys1q2bp3/ZP7PhqF4J/C/yL+Sdyo9uKM1jzKv1z98wTFAI+R//8W9/lrWqq7Waimr7l9QwF9nwL7Fq+vfAe8WKY/3X7HukP4xovgN7N1bpPP1rDTNWa1dkoFld/57M6+fPq2/LzqpU9mp81f2vf/7f33c5l61r927wVbLt2V79y96eNf/5eZW+Y+PyLkMgBPkHhP0DonwYfXf6N4T+BRP4O/Q3BP3LhPffOr3/0vLHmLfdrYr37v+8R/p/jbpV817I/9gm7MPI3xj1N4T8hcLU/6dNvqqzY9j1bvr8DwzD70n/AdM+Ar223vcvCIL+p4b/97/9qe43GF6N0/7e+B8Z2xTmvx81zBG0JsxWB2K0r2yviuM1pTF8uaRG0VvbDRFGDxA1jT+fYfZBEJ1S8RPh6uCxIFLKVKMa8Iwv+6mfw1pwaeo6FQj2IYbPy7gC572JCqVi652c/JrIzahzNtkzJGCWbzDrnxAXnt+n2cQYw/HZ8W1MO+OFQi7VGJQPpw1EcinEBNHqR+dAWpu6jdHcaLwMFAN/wqBp4KDB6Txrm/Wz4Q4XenfgQnIbvB1JhIF+6qTRE/PdWu7wHvQJgJ8BS6G+ON9o8IJQw1PqkWTE8/AnUpOUZMoJ89TsK1gh5gGKID5m5//YHsaxavTFwo/7OwJCloVdIbwf2rS6p/VzSpg/G69gxrfKXZHNCHM3WQ6otaAzqp9Xkxbe4um3kmqkCJggf34CuKFetFWm2gfAxzIVV3NWekbztfKENZB2TnxcHUknLUulaGKDuQBhkLzxZvbxiZ1q7AN8db0B5LTbo1B/PB33FOaLAyxxyL51YR5VYQWeLnFGL3yzAONVPhZ4ZBllhrDrHSU2JJC4sT5aNpdf7VX73TNTgivmQ3HGGtpbkfiBJB64Rc9SSyqPlqKqZCy+8Ft34A7P7+UxsUJkA+R8RglFYEamJjU27rxRdeZ8fLsZwAwtqc8eVQ/P3Zevaj5567lAwz6Sr8Gq6uWXTLgLsQuUklDhSfy4jb/gF3vLoWcY4v6gPMqMQwHoan9j8uuF0aoG2LnvIlifaD8ZmPpywTnd7gA9YMizIQEtxBS4vxykNkKCvU883irMKOB9dV4CqcJu0t/KKr/qHm6QIOsq5t7MsFtPyN1TDaw5X5r6LCarEK8kIHg+DxNLn2kDzWYsW8jj/N6DmLEc7e6+tyng7g95jFZwx1Jwj+GSWwT+qE2NbVf1ou9HqEUf3pT5tZesLZPTJLBFy1EX+hhH0W08s+ggjJtMcgKwimxpt0Y+3n5IVVwW4zSTB55uqAUC5FmGmxyZYbDD86iaIFzCYuJbKgHlmV6UTbxy2qULOtSm1zTMIbN1dtcBh4xIgf29P/EqtaLT/3raia80dYBf80uUFCD0xW8wP0yFLbJTa1suxawSLmlAob1j/TBXr2l9d4ek8JKBMVEFsfZ2X4LlrPS2r8rRyjLC4yhFDZ272qAjff3NG3Y8LreeDWltZ5Xe6Eqg26kvDmx2R0HSoRKmZmRWuOXDNampCJ0X4Pp8bs1agIIokGaSemseeFNsyixnRPd62meT+nxnjqrFJYgtBZSPqu4ei73/432KNSkuU4NxuOpKEH4E3btM3+t0yDYu57mChp8VGxl889hJLjFe8ttAWZMGIa6zC97n16s4ikwkb0ViZ8I6u8T2qTedJuRmd1fcTodffYAZ/U3ldXAsOINwGrjqj7FFv7ioJEkKh9+0WdG8cxHJG+2Dul8XoER+uHIoI8t4shpAiaeqGIfUPjejMz09YDXjkzdTWygQyOTYLTXYPdnGSeLh+GL7dX+9HzbbaH20PQ/7K8ikkNWSaiir9sCgEwMylMbYGikTkYDDwWVhX/8CNcm8W5lN7Bi5mejsu8Ifo7Jo+PnTMnbfGDunUIQm2/DcAR6EuQJcf6qzXTNa0ab5wFTEzPvP0WzLVyeimdJDYZkzE9liNxa2duSV66zZnjwsFPJq04cDt641QTN0WteCGtDEcGY6rXOHsVmje283wtSAKR6dFG0LbWEbL9njDbsBozCvrAe3TfNT4JBkCdaZEmFXoSb9ZOnOTUl6YD5ZZso2VHSGqhO4FDO/Q/tWVDhj5g1slhv51Y7203YNC9y+376ZupmpQ+4sYa+jpGymwUxKoOBro4IapLjDDnk3VCWNCjDcpaFPr9B2edbY8Ok2lflan8l1J+eOKq0sAwfWhwR5hBy5tKBPIQXI84KRk57VQyZ3bmcLfD1sBvN54Slr7gNQgTNoTPPziIo6BZ5K8U6EenLG1KAKzYopeicW8T5qUKykoJ2kcw362VrKQa0VN489K0g/wvzkyPL9E36gnS2WrDHgcMZZy7h5G2Ev8zYUe6uRuxHBbM8G83eaz0Y1IknTTS6s7oYGfjPMuy36h0tbqWmRD+0kNr4lbO3rlDclVmfl2O9Sc5tAZObnF/sMKk+2dmvSeet+QSv3oaRWFQ9mDr1bvr8BkXLkOs3NhxFidfbDO5akcrojn104CzxLhcbp6/so5/MRAPnTTtAi3uHOTcEqfNVKKTj2KCn0cMuCb2WOXYnDQdAW31XhEDqgpzfEsOorhSog75u7B28NYixTNNEmdd0R4MQOV5uudaYgTS4+L4rn5vK0t6Qc91ek7XWt81QAsbwCTDQybXa0BntXu2OK/2Z5nk+Viq+p9GthNjnGoaSNQt9HE0S4G4m8cmq7GLpX+VxGcR1c3NY0Fqq6NkcV7XJ3nnl9Oo8PN5zOfKytqWdbgBo5LJ0T+hVTWMRI1oUTvuUemwPl5KtJK8er1JKk8lszHM/5WnWXal7+bTYsgeeSsvQnEIveLKPYkD3FXhJK/v4kihY36di+xO+YyPH69Aaqj43xLRHgTI4at+NHa+xxK2dwF+phm4SRsaR57n3yyFf4yxOgibG4SwcF8wXKshPxJJDaj88OzaxvRuCs0heix0saX0T0fsikNFDMWIKl2VrYby5xBuRjsNJP+7IhOYW+Dt6AucMRRp/y0lwzH5tYxee3wXAI4yJwGPVDCybInvgItwgwMFaiSDntVlAYOFZJnBdA0VDTmt9dxJc6tyuqkXfM94IlTNDurg6YuxMOKaoDQAPL9S7KJ4b6tzhaF6ygPZgxTIo+wxjGFC2sTRFHFJGE4QdhouQ7xuuQ4Ys37gVix/NDt/dbBxYnfWY5DfJsXsv0e37oQHHtqYwCtnOgDS28weTsjymvONYQXw3mf6tm9b8gbS/V9z6XCZ/sFaF0FoIoEpq9g4s+8mGHlYwj3l12Ak60veQ84hNO3/URhIIVKE8Cgb6O5nuw3wRhGtywcAESgMujUf5pDd1UXnw6Al7mj9LXLIIV5mEUIMq5aokl4v47yBnS/5Lp6FbQ+XXHB0nI7Os+Br/h7eVqTVpGBFumV3KniT8OGcFnbi6HwRQTnQ4RuaDQkcCFbFerUqyPfZqIKEeBeisixcRZzizo32KrWpzpkuJ7hi/LKXul3U82Cb8efrHxuH8aHapIJAu/jfvm8M87O2Oe9QzbJ3/FGJeoE3u9z7dHnWxQKs7mkiJxuCtDe7FXLrnviMI4LWPSSl7yQZPPvjpZwIcYBdS6vCvMTY3xRdTsUK3jrFVz5Bo98I0iNoYmEaZzeoXeSnRkFhg7Tu2JcsnEV6AKX28CqZUbOc+5ysSx4V+YVY+k4UpbhjOfz9mi6uR1mRGuPxDBukapueyj+JTdMSdmhcY1tEvjYQH862RpHOE0LvWKcpXWAjNuI2j3Ss02ulMXSItZNh2YOqwD625jxphyvTj3+HmohcSuWwnKYN052pAshAy2n9exM4hGJSeDSvmy0e+/CEFMq30yCB1ehL+CxOOQj2nLU4AjR9jXEowAIrzmvo6L3yRE0rdx3AV7YomXImhjQKH1mzFpVRILH+ExtQqSKPD0ndWajZ0fru2ovtsaX2N6LB3k5stWdX7vxDMa8u6wQWJaJibTnjm+ziOaIEpOTdIxoszuj/fkaVJ0rFflvkf8dEZDlrMgOf6SavB3ynyNUyXtr96J8OzERm+mQwUR9ox9Gc4KwzOx+lWnxP1MSxVWxpWrO06VVDilYGrO50vPHkGXeUv7G5oGfhuTRiCrNU7OTZUqXsgVJcGlT7vH0yowDnuvQyl2l0G3yS9Bepxs6mtJhsn+KCDV+WfGfeCExMXjPV0XdvfGXGiJ2w9/L5C8RAetoGmPgdlZM1gEnJFpDPHiaz+G2iryIGtz4cphrfYrjNXvCwDwOnotQZI0kZoMooXKqq+lpRZhmzs/UqKQwPtgxpKefm16lY8/ILbffVsDWWIFEeGXW08AS1paWOQ3iMZlaSK7YjWWeY9/aK14PZGFL6YvK91DJiguFHj+aPFbXgh13O6qOjlym/WZzzGM4dx056VAI8je3gqGvJlQvvR9JI2qFY5VIwXXlIKXHpV8UejkESi5z60qH4nunOxnl3H1nrxJ+pLqkCGt4Di1LvGZDuA1EueCfte/IU1iIMAbZXhvj87w3NpGuzaNX/ZpgQggQUP+1TMpZGFeM3XUTUPW5r+lxw8wCE/AbLkRQE5T3l2FxD7ZnnQ3DImUVbipYpgeg/Ou+tg9CUzWTHlCxvFcMxFb8vLDPPipt4lYAtMyuUfmvID/jON8lB+nzgFiZ7JhGRZjwoJb0D+w6g7C72ZOYjKLV8ItSTYbU1sv73XpPIshXwY7bBg+mtf9OS6q7rc7z9iI8Czb4PYKkkaHWhVPCoS3dEkteC1GL3WV01dhUWBwijimBUMON6BtVzjblL3Mnhdv7OC+VI7PLFkVyKpCWe5sIuNY0PWGEytDLsSQmRFQ1Z2y6AeSLXAN+4rALAWJJ8BIf1t5oXRFJACia9VdSoWhuK4lCFToPTDO4IbnSFl+WE0ggS9iJBCfCOqqNRJfm7uMrTH/hLj/lbP+tvrnOgInaGUnHzGDhjJaZIgG+z5hX6qf1gr3eUQikn2IprojEzllcZazDEMZ6/TO8TM1d4SFq5fijqvbL/t95ihOAVZ7O2qzxQnzSHd4Z6uBjgBzmbj9OBZiLIaMueictxKcsZe3qtMu/ct5j9x92jq8rVzJtJx+JQguncVPPpW8KQXamj5CB3oYWMSBZch/PlNaE0KHOmV8iDtQ3X4l+YvlkMptJRpUTzV59tGKus8mP0YibzfgB3IgoskG9gqp7I5ZtHeLon08riaS+BndygQQ6GovxBtNiXZA5d74IRiaYtIBQkcLeaZx2DPkQMRkt9Dq0715mHpvo3jJsrww8QcR7cYhlFvntsHJ7hKQkeJy6gIMdxp+jrL7dNSkXk4pI+vbgC87+kGAtwkp41X+mhv8MiZMoba5bHKo4LmDPZVCxqf1mlEQ1lJSNWABPR3TIySkSNjKcjVB9BtTMMKBIEb/24xCjxb+LIRWnEAdYZiThjzwxa69aG6+AIy7ZkuQDQOqMLJi9fHDap8vv44BEGW0Mmt0sBYW2Eqg2qW2OhClLicawzsFjM12Fw7d2LgcYV+0r1NUHXbxn1nVL+ZD3EgvkYQRHCgR7esMteXWXCCi3QrfZl9SbnIk5Zx+lix1j4nChWpPO5dh4z+lfbpMJIGYpcUl6kfU/TshssFxqU6uAeHCA6Vvp8CfwI+j3/YM1Dnx2O3aSyFPbyuGjaY0P2miS5hYo92LgayDwy+fc2X+uwb9G1BOftZWbGvmUlUWUJPrxchtKLOON03wXkmxHRrQF4A3lbps/5tdz2MmV5P8WLFDwJfbNGQyh4gYQ59JRqPfWH8NiQA5vzr6L2e8hB3rHGSN2AudWmsKYJjkDjwOUbv7JWtyaREK3s/HJej2+qL2Gau2JsIJtSUSMCditmB24fnuUimHkod9uizFkZhj+ORvFEPcYpRLPhP17X3Xhsg+xAmETl3ZWvvYNXnlhxHbgMiq6NPq3S49a+DkgeBtc3N4k76AmCleNe9+kNAu+th4xdeHpkGQRe57aTveYhjmz3/8HwmG4iNSGAAA',
            'Content-Type': 'application/json; charset=UTF-8',
            'Content-Length': '119',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        },
        body: JSON.stringify({ "phoneNumber": "+" + phoneNumber, "deviceId": deviceId, "requestedUserId": userId })
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

const getTokenVeryfLink = (userId, linkId) => new Promise((resolve, reject) => {
    fetch('https://mobile-api.hopper.com/api/v2/target/' + linkId, {
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': 'H4sIAAAAAAAAAJ13Vw+1ynLlf/le8T3kdN7IOWdGI4scNmmT2Vf+78O1ZY3mzRqEhOjuquruCqvWP/90ZTXt3f78+fuff46tWpXyz99/CqIkygIi/kFnFP0PDKLIf2R1UfwDhsqqyouaygviz7/9KauzK6r/lCCKui5pCqbhkkAKAn5ns2X5L2Xz+Fc7L0u1/jXOx7Rn3XR21fXXMmTPu+ys1q2bp3/ZP7PhqF4J/C/yL+Sdyo9uKM1jzKv1z98wTFAI+R//8W9/lrWqq7Waimr7l9QwF9nwL7Fq+vfAe8WKY/3X7HukP4xovgN7N1bpPP1rDTNWa1dkoFld/57M6+fPq2/LzqpU9mp81f2vf/7f33c5l61r927wVbLt2V79y96eNf/5eZW+Y+PyLkMgBPkHhP0DonwYfXf6N4T+BRP4O/Q3BP3LhPffOr3/0vLHmLfdrYr37v+8R/p/jbpV817I/9gm7MPI3xj1N4T8hcLU/6dNvqqzY9j1bvr8DwzD70n/AdM+Ar223vcvCIL+p4b/97/9qe43GF6N0/7e+B8Z2xTmvx81zBG0JsxWB2K0r2yviuM1pTF8uaRG0VvbDRFGDxA1jT+fYfZBEJ1S8RPh6uCxIFLKVKMa8Iwv+6mfw1pwaeo6FQj2IYbPy7gC572JCqVi652c/JrIzahzNtkzJGCWbzDrnxAXnt+n2cQYw/HZ8W1MO+OFQi7VGJQPpw1EcinEBNHqR+dAWpu6jdHcaLwMFAN/wqBp4KDB6Txrm/Wz4Q4XenfgQnIbvB1JhIF+6qTRE/PdWu7wHvQJgJ8BS6G+ON9o8IJQw1PqkWTE8/AnUpOUZMoJ89TsK1gh5gGKID5m5//YHsaxavTFwo/7OwJCloVdIbwf2rS6p/VzSpg/G69gxrfKXZHNCHM3WQ6otaAzqp9Xkxbe4um3kmqkCJggf34CuKFetFWm2gfAxzIVV3NWekbztfKENZB2TnxcHUknLUulaGKDuQBhkLzxZvbxiZ1q7AN8db0B5LTbo1B/PB33FOaLAyxxyL51YR5VYQWeLnFGL3yzAONVPhZ4ZBllhrDrHSU2JJC4sT5aNpdf7VX73TNTgivmQ3HGGtpbkfiBJB64Rc9SSyqPlqKqZCy+8Ft34A7P7+UxsUJkA+R8RglFYEamJjU27rxRdeZ8fLsZwAwtqc8eVQ/P3Zevaj5567lAwz6Sr8Gq6uWXTLgLsQuUklDhSfy4jb/gF3vLoWcY4v6gPMqMQwHoan9j8uuF0aoG2LnvIlifaD8ZmPpywTnd7gA9YMizIQEtxBS4vxykNkKCvU883irMKOB9dV4CqcJu0t/KKr/qHm6QIOsq5t7MsFtPyN1TDaw5X5r6LCarEK8kIHg+DxNLn2kDzWYsW8jj/N6DmLEc7e6+tyng7g95jFZwx1Jwj+GSWwT+qE2NbVf1ou9HqEUf3pT5tZesLZPTJLBFy1EX+hhH0W08s+ggjJtMcgKwimxpt0Y+3n5IVVwW4zSTB55uqAUC5FmGmxyZYbDD86iaIFzCYuJbKgHlmV6UTbxy2qULOtSm1zTMIbN1dtcBh4xIgf29P/EqtaLT/3raia80dYBf80uUFCD0xW8wP0yFLbJTa1suxawSLmlAob1j/TBXr2l9d4ek8JKBMVEFsfZ2X4LlrPS2r8rRyjLC4yhFDZ272qAjff3NG3Y8LreeDWltZ5Xe6Eqg26kvDmx2R0HSoRKmZmRWuOXDNampCJ0X4Pp8bs1agIIokGaSemseeFNsyixnRPd62meT+nxnjqrFJYgtBZSPqu4ei73/432KNSkuU4NxuOpKEH4E3btM3+t0yDYu57mChp8VGxl889hJLjFe8ttAWZMGIa6zC97n16s4ikwkb0ViZ8I6u8T2qTedJuRmd1fcTodffYAZ/U3ldXAsOINwGrjqj7FFv7ioJEkKh9+0WdG8cxHJG+2Dul8XoER+uHIoI8t4shpAiaeqGIfUPjejMz09YDXjkzdTWygQyOTYLTXYPdnGSeLh+GL7dX+9HzbbaH20PQ/7K8ikkNWSaiir9sCgEwMylMbYGikTkYDDwWVhX/8CNcm8W5lN7Bi5mejsu8Ifo7Jo+PnTMnbfGDunUIQm2/DcAR6EuQJcf6qzXTNa0ab5wFTEzPvP0WzLVyeimdJDYZkzE9liNxa2duSV66zZnjwsFPJq04cDt641QTN0WteCGtDEcGY6rXOHsVmje283wtSAKR6dFG0LbWEbL9njDbsBozCvrAe3TfNT4JBkCdaZEmFXoSb9ZOnOTUl6YD5ZZso2VHSGqhO4FDO/Q/tWVDhj5g1slhv51Y7203YNC9y+376ZupmpQ+4sYa+jpGymwUxKoOBro4IapLjDDnk3VCWNCjDcpaFPr9B2edbY8Ok2lflan8l1J+eOKq0sAwfWhwR5hBy5tKBPIQXI84KRk57VQyZ3bmcLfD1sBvN54Slr7gNQgTNoTPPziIo6BZ5K8U6EenLG1KAKzYopeicW8T5qUKykoJ2kcw362VrKQa0VN489K0g/wvzkyPL9E36gnS2WrDHgcMZZy7h5G2Ev8zYUe6uRuxHBbM8G83eaz0Y1IknTTS6s7oYGfjPMuy36h0tbqWmRD+0kNr4lbO3rlDclVmfl2O9Sc5tAZObnF/sMKk+2dmvSeet+QSv3oaRWFQ9mDr1bvr8BkXLkOs3NhxFidfbDO5akcrojn104CzxLhcbp6/so5/MRAPnTTtAi3uHOTcEqfNVKKTj2KCn0cMuCb2WOXYnDQdAW31XhEDqgpzfEsOorhSog75u7B28NYixTNNEmdd0R4MQOV5uudaYgTS4+L4rn5vK0t6Qc91ek7XWt81QAsbwCTDQybXa0BntXu2OK/2Z5nk+Viq+p9GthNjnGoaSNQt9HE0S4G4m8cmq7GLpX+VxGcR1c3NY0Fqq6NkcV7XJ3nnl9Oo8PN5zOfKytqWdbgBo5LJ0T+hVTWMRI1oUTvuUemwPl5KtJK8er1JKk8lszHM/5WnWXal7+bTYsgeeSsvQnEIveLKPYkD3FXhJK/v4kihY36di+xO+YyPH69Aaqj43xLRHgTI4at+NHa+xxK2dwF+phm4SRsaR57n3yyFf4yxOgibG4SwcF8wXKshPxJJDaj88OzaxvRuCs0heix0saX0T0fsikNFDMWIKl2VrYby5xBuRjsNJP+7IhOYW+Dt6AucMRRp/y0lwzH5tYxee3wXAI4yJwGPVDCybInvgItwgwMFaiSDntVlAYOFZJnBdA0VDTmt9dxJc6tyuqkXfM94IlTNDurg6YuxMOKaoDQAPL9S7KJ4b6tzhaF6ygPZgxTIo+wxjGFC2sTRFHFJGE4QdhouQ7xuuQ4Ys37gVix/NDt/dbBxYnfWY5DfJsXsv0e37oQHHtqYwCtnOgDS28weTsjymvONYQXw3mf6tm9b8gbS/V9z6XCZ/sFaF0FoIoEpq9g4s+8mGHlYwj3l12Ak60veQ84hNO3/URhIIVKE8Cgb6O5nuw3wRhGtywcAESgMujUf5pDd1UXnw6Al7mj9LXLIIV5mEUIMq5aokl4v47yBnS/5Lp6FbQ+XXHB0nI7Os+Br/h7eVqTVpGBFumV3KniT8OGcFnbi6HwRQTnQ4RuaDQkcCFbFerUqyPfZqIKEeBeisixcRZzizo32KrWpzpkuJ7hi/LKXul3U82Cb8efrHxuH8aHapIJAu/jfvm8M87O2Oe9QzbJ3/FGJeoE3u9z7dHnWxQKs7mkiJxuCtDe7FXLrnviMI4LWPSSl7yQZPPvjpZwIcYBdS6vCvMTY3xRdTsUK3jrFVz5Bo98I0iNoYmEaZzeoXeSnRkFhg7Tu2JcsnEV6AKX28CqZUbOc+5ysSx4V+YVY+k4UpbhjOfz9mi6uR1mRGuPxDBukapueyj+JTdMSdmhcY1tEvjYQH862RpHOE0LvWKcpXWAjNuI2j3Ss02ulMXSItZNh2YOqwD625jxphyvTj3+HmohcSuWwnKYN052pAshAy2n9exM4hGJSeDSvmy0e+/CEFMq30yCB1ehL+CxOOQj2nLU4AjR9jXEowAIrzmvo6L3yRE0rdx3AV7YomXImhjQKH1mzFpVRILH+ExtQqSKPD0ndWajZ0fru2ovtsaX2N6LB3k5stWdX7vxDMa8u6wQWJaJibTnjm+ziOaIEpOTdIxoszuj/fkaVJ0rFflvkf8dEZDlrMgOf6SavB3ynyNUyXtr96J8OzERm+mQwUR9ox9Gc4KwzOx+lWnxP1MSxVWxpWrO06VVDilYGrO50vPHkGXeUv7G5oGfhuTRiCrNU7OTZUqXsgVJcGlT7vH0yowDnuvQyl2l0G3yS9Bepxs6mtJhsn+KCDV+WfGfeCExMXjPV0XdvfGXGiJ2w9/L5C8RAetoGmPgdlZM1gEnJFpDPHiaz+G2iryIGtz4cphrfYrjNXvCwDwOnotQZI0kZoMooXKqq+lpRZhmzs/UqKQwPtgxpKefm16lY8/ILbffVsDWWIFEeGXW08AS1paWOQ3iMZlaSK7YjWWeY9/aK14PZGFL6YvK91DJiguFHj+aPFbXgh13O6qOjlym/WZzzGM4dx056VAI8je3gqGvJlQvvR9JI2qFY5VIwXXlIKXHpV8UejkESi5z60qH4nunOxnl3H1nrxJ+pLqkCGt4Di1LvGZDuA1EueCfte/IU1iIMAbZXhvj87w3NpGuzaNX/ZpgQggQUP+1TMpZGFeM3XUTUPW5r+lxw8wCE/AbLkRQE5T3l2FxD7ZnnQ3DImUVbipYpgeg/Ou+tg9CUzWTHlCxvFcMxFb8vLDPPipt4lYAtMyuUfmvID/jON8lB+nzgFiZ7JhGRZjwoJb0D+w6g7C72ZOYjKLV8ItSTYbU1sv73XpPIshXwY7bBg+mtf9OS6q7rc7z9iI8Czb4PYKkkaHWhVPCoS3dEkteC1GL3WV01dhUWBwijimBUMON6BtVzjblL3Mnhdv7OC+VI7PLFkVyKpCWe5sIuNY0PWGEytDLsSQmRFQ1Z2y6AeSLXAN+4rALAWJJ8BIf1t5oXRFJACia9VdSoWhuK4lCFToPTDO4IbnSFl+WE0ggS9iJBCfCOqqNRJfm7uMrTH/hLj/lbP+tvrnOgInaGUnHzGDhjJaZIgG+z5hX6qf1gr3eUQikn2IprojEzllcZazDEMZ6/TO8TM1d4SFq5fijqvbL/t95ihOAVZ7O2qzxQnzSHd4Z6uBjgBzmbj9OBZiLIaMueictxKcsZe3qtMu/ct5j9x92jq8rVzJtJx+JQguncVPPpW8KQXamj5CB3oYWMSBZch/PlNaE0KHOmV8iDtQ3X4l+YvlkMptJRpUTzV59tGKus8mP0YibzfgB3IgoskG9gqp7I5ZtHeLon08riaS+BndygQQ6GovxBtNiXZA5d74IRiaYtIBQkcLeaZx2DPkQMRkt9Dq0715mHpvo3jJsrww8QcR7cYhlFvntsHJ7hKQkeJy6gIMdxp+jrL7dNSkXk4pI+vbgC87+kGAtwkp41X+mhv8MiZMoba5bHKo4LmDPZVCxqf1mlEQ1lJSNWABPR3TIySkSNjKcjVB9BtTMMKBIEb/24xCjxb+LIRWnEAdYZiThjzwxa69aG6+AIy7ZkuQDQOqMLJi9fHDap8vv44BEGW0Mmt0sBYW2Eqg2qW2OhClLicawzsFjM12Fw7d2LgcYV+0r1NUHXbxn1nVL+ZD3EgvkYQRHCgR7esMteXWXCCi3QrfZl9SbnIk5Zx+lix1j4nChWpPO5dh4z+lfbpMJIGYpcUl6kfU/TshssFxqU6uAeHCA6Vvp8CfwI+j3/YM1Dnx2O3aSyFPbyuGjaY0P2miS5hYo92LgayDwy+fc2X+uwb9G1BOftZWbGvmUlUWUJPrxchtKLOON03wXkmxHRrQF4A3lbps/5tdz2MmV5P8WLFDwJfbNGQyh4gYQ59JRqPfWH8NiQA5vzr6L2e8hB3rHGSN2AudWmsKYJjkDjwOUbv7JWtyaREK3s/HJej2+qL2Gau2JsIJtSUSMCditmB24fnuUimHkod9uizFkZhj+ORvFEPcYpRLPhP17X3Xhsg+xAmETl3ZWvvYNXnlhxHbgMiq6NPq3S49a+DkgeBtc3N4k76AmCleNe9+kNAu+th4xdeHpkGQRe57aTveYhjmz3/8HwmG4iNSGAAA',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        }
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

const veryfToken = (userId, deviceId, token) => new Promise((resolve, reject) => {
    fetch('https://mobile-api.hopper.com/api/v2/registrations/verify_code', {
        method: 'POST',
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': 'H4sIAAAAAAAAAJ131w61SpPdu3y3zDnkdO7IOWcsyyKHTdpk9mje3fxjjSzfjYyQEN1dVd1dYdX69z9dWU17tz9//vn3P8dWrUr5558/GU5BeZajf1V0Tf2F4QXyVwZl0F84huAkgUJlDZN//u1PWZ1dUf2nBFHUdUlTMA2XBFIQ8DubLct/ThXz+Hc7L0u1/j3Ox7Rn3XR21fX3MmTPu+ys1q2bp3/ZP7PhqF4J/G/yb+Sdyo9uKM1jzKv1zz8wTFAI+R//8W9/lrWqq7Waimr7l9QwF9nwL7Fq+l+B94oVx/qv2fdIfxjRfAf2bqzSefrXGmas1q7IQLO6/lcyr58/r74tO6tS2avxVfc//v3//r7LuWxdu3eDr5Jtz/bqX/b2rPnPz6v0HRuXdxkCIchfEPYXRPkw+u70Hwj9Gybwd+gfCPqXCe+/dHr/R8sfY952tyreu//zHun/NepWzXsh/22bsA8j/2DUPxDyNwpT/582+arOjmHXu+nz3zAMvyf9C6Z9BHptve/fEAT9dw3/z3/7U91vMLwap/298T8ytinMfz1qmCNoTZitDsRoX9leFcdrSmP4ckmNore2GyKMHiBqGn8+w+yDIDql4ifC1cFjQaSUqUY14Blf9lM/h7Xg0tR1KhDsQwyfl3EFznsTFUrF1js5+TWRm1HnbLJnSMAs32DWPyEuPL9Ps4kxhuOz49uYdsYLhVyqMSgfThuI5FKICaLVj86BtDZ1G6O50XgZKAb+hEHTwEGD03nWNutnwx0u9O7AheQ2eDuSCAP91EmjJ+a7tdzhPegTAD8DlkJ9cb7R4AWhhqfUI8mI5+FPpCYpyZQT5qnZV7BCzAMUQXzMzv+xPYxj1eiLhR/3dwSELAu7Qng/tGl1T+vnlDB/Nl7BjG+VuyKbEeZushxQa0FnVD+vJi28xdNvJdVIETBB/vwEcEO9aKtMtQ+Aj2Uqruas9Izma+UJayDtnPi4OpJOWpZK0cQGcwHCIHnjzezjEzvV2Af46noDyGm3R6H+eDruKcwXB1jikH3rwjyqwgo8XeKMXvhmAcarfCzwyDLKDGHXO0psSCBxY320bC6/2qv2u2emBFfMh+KMNbS3IvEDSTxwi56lllQeLUVVyVh84bfuwB2e38tjYoXIBsj5jBKKwIxMTWps3Hmj6sz5+HYzgBlaUp89qh6euy9f1Xzy1nOBhn0kX4NV1csvmXAXYhcoJaHCk/hxG3/BL0ZnlGcY4v6gPMqMQwHoan9j8uuF0aoG2LnvIlifaD8ZmPpywTnd7gA9YMizIQEtxBS4vxykNkKCvU883irMKOB9dV4CqcJu0t/KKr/qHm6QIOsq5t7MsFtPyN1TDaw5X5r6LCarEK8kIHg+DxNLn2kDzWYsW8jj/N6DmLEc7e6+tyng7g95jFZwx1Jwj+GSWwT+qE2NbVf1ou9HqEUf3pT5tZesLZPTJLBFy1EX+hhH0W08s+ggjJtMcgKwimxpt0Y+3n5IVVwW4zSTB55uqAUC5FmGmxyZYbDD86iaIFzCYuJbKvFiiF6UTbxy2qULOtSm1zTMIbN1dtcBh4xIgf29P/EqtaLT/3raia80dYBf80uUFCD0xW8wP0yFLbJTa1suxawSLmlAob1j/TBXr2l9d4ek8JKBMVEFsfZ2X4LlrPS2r8rRyjLC4yhFDZ272qAjff3NG3Y8LreeDWltZ5Xe6Eqg26kvDmx2R0HSoRKmZmRWuOXDNampCJ0X4Pp8bs1agIIokGaSemseeFNsyixnRPd62meT+nxnjqrFJYgtBZSPqu4ei73/432KNSkuU4NxuOpKEH4E3btM3+t0yDYu57mChp8VGxl889hJLjFe8ttAWZMGIa6zC97n16s4ikwkb0ViZ8I6u8T2qTedJuRmd1fcTodffYAZ/U3ldXAsOINwGrjqj7FFv7ioJEkKh9+0WdG8cxHJG+2Dul8XoER+uHIoI8t4shpAiaeqGIfUPjejMz09YDXjkzdTWygQyOTYLTXYPdnGSeLh+GL7dX+9HzbbaH20PQ/7K8ikkNWSaiir9sCgEwMylMbYGikTkYDDwWVhX/8CNcm8W5lN7Bi5mejsu8Ifo7Jo+PnTMnbfGDunUIQm2/DcAR6EuQJcf6qzXTNa0ab5wFTEzPvP0WzLVyeimdJDYZkzE9liNxa2duSV66zZnjwsFPJq04cDt641QTN0WteCGtDEcGY6rXOHsVmje283wtSAKR6dFG0LbWEbL9njDbsBozCvrAe3TfNT4JBkCdaZEmFXoSb9ZOnOTUl6YD5ZZso2VHSGqhO4FDO/Q/tWVDhj5g1slhv51Y7203YNC9y+376ZupmpQ+4sYa+jpGymwUxKoOBro4IapLjDDnk3VCWNCjDcpaFPr9B2edbY8Ok2lflan8l1J+eOKq0sAwfWhwR5hBy5tKBPIQXI84KRk57VQyZ3bmcLfD1sBvN54Slr7gNQgTNoTPPziIo6BZ5K8U6EenLG1KAKzYopeicW8T5qUKykoJ2kcw362VrKQa0VN489K0g/wvzkyPL9E36gnS2WrDHgcMZZy7h5G2Ev8zYUe6uRuxHBbM8G83eaz0Y1IknTTS6s7oYGfjPMuy36h0tbqWmRD+0kNr4lbO3rlDclVmfl2O9Sc5tAZObnF/sMKk+2dmvSeet+QSv3oaRWFQ9mDr1bvr8BkXLkOs3NhxFidfbDO5akcrojn104CzxLhcbp6/so5/MRAPnTTtAi3uHOTcEqfNVKKTj2KCn0cMuCb2WOXYnDQdAW31XhEDqgpzfEsOorhSog75u7B28NYixTNNEmdd0R4MQOV5uudaYgTS4+L4rn5vK0t6Qc91ek7XWt81QAsbwCTDQybXa0BntXu2OK/2Z5nk+Viq+p9GthNjnGoaSNQt9HE0S4G4m8cmq7GLpX+VxGcR1c3NY0Fqq6NkcV7XJ3nnl9Oo8PN5zOfKytqWdbgBo5LJ0T+hVTWMRI1oUTvuUemwPl5KtJK8er1JKk8lszHM/5WnWXal7+bTYsgeeSsvQnEIveLKPYkD3FXhJK/v4kihY36di+xO+YyPH69Aaqj43xLRHgTI4at+NHa+xxK2dwF+phm4SRsaR57n3yyFf4yxOgibG4SwcF8wXKshPxJJDaj88OzaxvRuCs0heix0saX0T0fsikNFDMWIKl2VrYby5xBuRjsNJP+7IhOYW+Dt6AucMRRp/y0lwzH5tYxee3wXAI4yJwGPVDCybInvgItwgwMFaiSDntVlAYOFZJnBdA0VDTmt9dxJc6tyuqkXfM94IlTNDurg6YuxMOKaoDQAPL9S7KJ4b6tzhaF6ygPZgxTIo+wxjGFC2sTRFHFJGE4QdhouQ7xuuQ4Ys37gVix/NDt/dbBxYnfWY5DfJsXsv0e37oQHHtqYwCtnOgDS28weTsjymvONYQXw3mf6tm9b8gbS/V9z6XCZ/sFaF0FoIoEpq9g4s+8mGHlYwj3l12Ak60veQ84hNO3/URhIIVKE8Cgb6O5nuw3wRhGtywcAESgMujUf5pDd1UXnw6Al7mj9LXLIIV5mEUIMq5aokl4v47yBnS/5Lp6FbQ+XXHB0nI7Os+Br/h7eVqTVpGBFumV3KniT8OGcFnbi6HwRQTnQ4RuaDQkcCFbFerUqyPfZqIKEeBeisixcRZzizo32KrWpzpkuJ7hi/LKXul3U82Cb8efrHxuH8aHapIJAu/jfvm8M87O2Oe9QzbJ3/FGJeoE3u9z7dHnWxQKs7mkiJxuCtDe7FXLrnviMI4LWPSSl7yQZPPvjpZwIcYBdS6vCvMTY3xRdTsUK3jrFVz5Bo98I0iNoYmEaZzeoXeSnRkFhg7Tu2JcsnEV6AKX28CqZUbOc+5ysSx4V+YVY+k4UpbhjOfz9mi6uR1mRGuPxDBukapueyj+JTdMSdmhcY1tEvjYQH862RpHOE0LvWKcpXWAjNuI2j3Ss02ulMXSItZNh2YOqwD625jxphyvTj3+HmohcSuWwnKYN052pAshAy2n9exM4hGJSeDSvmy0e+/CEFMq30yCB1ehL+CxOOQj2nLU4AjR9jXEowAIrzmvo6L3yRE0rdx3AV7YomXImhjQKH1mzFpVRILH+ExtQqSKPD0ndWajZ0fru2ovtsaX2N6LB3k5stWdX7vxDMa8u6wQWJaJibTnjm+ziOaIEpOTdIxoszuj/fkaVJ0rFflvkf8dEZDlrMgOf6SavB3ynyNUyXtr96J8OzERm+mQwUR9ox9Gc4KwzOx+lWnxP1MSxVWxpWrO06VVDilYGrO50vPHkGXeUv7G5oGfhuTRiCrNU7OTZUqXsgVJcGlT7vH0yowDnuvQyl2l0G3yS9Bepxs6mtJhsn+KCDV+WfGfeCExMXjPV0XdvfGXGiJ2w9/L5C8RAetoGmPgdlZM1gEnJFpDPHiaz+G2iryIGtz4cphrfYrjNXvCwDwOnotQZI0kZoMooXKqq+lpRZhmzs/UqKQwPtgxpKefm16lY8/ILbffVsDWWIFEeGXW08AS1paWOQ3iMZlaSK7YjWWeY9/aK14PZGFL6YvK91DJiguFHj+aPFbXgh13O6qOjlym/WZzzGM4dx056VAI8je3gqGvJlQvvR9JI2qFY5VIwXXlIKXHpV8UejkESi5z60qH4nunOxnl3H1nrxJ+pLqkCGt4Di1LvGZDuA1EueCfte/IU1iIMAbZXhvj87w3NpGuzaNX/ZpgQggQUP+1TMpZGFeM3XUTUPW5r+lxw8wCE/AbLkRQE5T3l2FxD7ZnnQ3DImUVbipYpgeg/Ou+tg9CUzWTHlCxvFcMxFb8vLDPPipt4lYAtMyuUfmvID/jON8lB+nzgFiZ7JhGRZjwoJb0D+w6g7C72ZOYjKLV8ItSTYbU1sv73XpPIshXwY7bBg+mtf9OS6q7rc7z9iI8Czb4PYKkkaHWhVPCoS3dEkteC1GL3WV01dhUWBwijimBUMON6BtVzjblL3Mnhdv7OC+VI7PLFkVyKpCWe5sIuNY0PWGEytDLsSQmRFQ1Z2y6AeSLXAN+4rALAWJJ8BIf1t5oXRFJACia9VdSoWhuK4lCFToPTDO4IbnSFl+WE0ggS9iJBCfCOqqNRJfm7uMrTH/hLj/lbP+tvrnOgInaGUnHzGDhjJaZIgG+z5hX6qf1gr3eUQikn2IprojEzllcZazDEMZ6/TO8TM1d4SFq5fijqvbL/t95ihOAVZ7O2qzxQnzSHd4Z6uBjgBzmbj9OBZiLIaMueictxKcsZe3qtMu/ct5j9x92jq8rVzJtJx+JQguncVPPpW8KQXamj5CB3oYWMSBZch/PlNaE0KHOmV8iDtQ3X4l+YvlkMptJRpUTzV59tGKus8mP0YibzfgB3IgoskG9gqp7I5ZtHeLon08riaS+BndygQQ6GovxBtNiXZA5d74IRiaYtIBQkcLeaZx2DPkQMRkt9Dq0715mHpvo3jJsrww8QcR7cYhlFvntsHJ7hKQkeJy6gIMdxp+jrL7dNSkXk4pI+vbgC87+kGAtwkp41X+mhv8MiZMoba5bHKo4LmDPZVCxqf1mlEQ1lJSNWABPR3TIySkSNjKcjVB9BtTMMKBIEb/24xCjxb+LIRWnEAdYZiThjzwxa69aG6+AIy7ZkuQDQOqMLJi9fHDap8vv44BEGW0Mmt0sBYW2Eqg2qW2OhClLicawzsFjM12Fw7d2LgcYV+0r1NUHXbxn1nVL+ZD3EgvkYQRHCgR7esMteXWXCCi3QrfZl9SbnIk5Zx+lix1j4nChWpPO5dh4z+lfbpMJIGYpcUl6kfU/TshssFxqU6uAeHCA6Vvp8CfwI+j3/YM1Dnx2O3aSyFPbyuGjaY0P2miS5hYo92LgayDwy+fc2X+uwb9G1BOftZWbGvmUlUWUJPrxchtKLOON03wXkmxHRrQF4A3lbps/5tdz2MmV5P8WLFDwJfbNGQyh4gYQ59JRqPfWH8NiQA5vzr6L2e8hB3rHGSN2AudWmsKYJjkDjwOUbv7JWtyaREK3s/HJej2+qL2Gau2JsIJtSUSMCditmB24fnuUimHkod9uizFkZhj+ORvFEPcYpRLPhP17X3Xhsg+xAmETl3ZWvvYNXnlhxHbgMiq6NPq3S49a+DkgeBtc3N4k76AmCleNe9+kNAu+th4xdeHpkGQRe57aTveYhjmz3/8b4i2EBxSGAAA',
            'Content-Type': 'application/json; charset=UTF-8',
            'Content-Length': '177',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        },
        body: JSON.stringify({ "deviceId": deviceId, "previousId": userId, "userId": userId, "verificationCode": token })
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

const finalRegistration = (userId, deviceId, firstName, surName, email) => new Promise((resolve, reject) => {
    fetch('https://mobile-api.hopper.com/api/v2/registrations/finalize', {
        method: 'POST',
        headers: {
            'X-User-Id': userId,
            'X-Build-Number': '116827',
            'X-Locale': 'en_US',
            'X-Currency': 'AFN',
            'X-TimeZone': 'America/New_York',
            'H-Request': 'H4sIAAAAAAAAAJ131w61SpPdu3y3zDnkdO7IOWcsyyKHTdpk9mje3fxjjSzfjYyQEN1dVd1dYdX69z9dWU17tz9//vn3P8dWrUr5558/GU5BeZajf1V0Tf2F4QXyVwZl0F84huAkgUJlDZN//u1PWZ1dUf2nBFHUdUlTMA2XBFIQ8DubLct/ThXz+Hc7L0u1/j3Ox7Rn3XR21fX3MmTPu+ys1q2bp3/ZP7PhqF4J/G/yb+Sdyo9uKM1jzKv1zz8wTFAI+R//8W9/lrWqq7Waimr7l9QwF9nwL7Fq+l+B94oVx/qv2fdIfxjRfAf2bqzSefrXGmas1q7IQLO6/lcyr58/r74tO6tS2avxVfc//v3//r7LuWxdu3eDr5Jtz/bqX/b2rPnPz6v0HRuXdxkCIchfEPYXRPkw+u70Hwj9Gybwd+gfCPqXCe+/dHr/R8sfY952tyreu//zHun/NepWzXsh/22bsA8j/2DUPxDyNwpT/582+arOjmHXu+nz3zAMvyf9C6Z9BHptve/fEAT9dw3/z3/7U91vMLwap/298T8ytinMfz1qmCNoTZitDsRoX9leFcdrSmP4ckmNore2GyKMHiBqGn8+w+yDIDql4ifC1cFjQaSUqUY14Blf9lM/h7Xg0tR1KhDsQwyfl3EFznsTFUrF1js5+TWRm1HnbLJnSMAs32DWPyEuPL9Ps4kxhuOz49uYdsYLhVyqMSgfThuI5FKICaLVj86BtDZ1G6O50XgZKAb+hEHTwEGD03nWNutnwx0u9O7AheQ2eDuSCAP91EmjJ+a7tdzhPegTAD8DlkJ9cb7R4AWhhqfUI8mI5+FPpCYpyZQT5qnZV7BCzAMUQXzMzv+xPYxj1eiLhR/3dwSELAu7Qng/tGl1T+vnlDB/Nl7BjG+VuyKbEeZushxQa0FnVD+vJi28xdNvJdVIETBB/vwEcEO9aKtMtQ+Aj2Uqruas9Izma+UJayDtnPi4OpJOWpZK0cQGcwHCIHnjzezjEzvV2Af46noDyGm3R6H+eDruKcwXB1jikH3rwjyqwgo8XeKMXvhmAcarfCzwyDLKDGHXO0psSCBxY320bC6/2qv2u2emBFfMh+KMNbS3IvEDSTxwi56lllQeLUVVyVh84bfuwB2e38tjYoXIBsj5jBKKwIxMTWps3Hmj6sz5+HYzgBlaUp89qh6euy9f1Xzy1nOBhn0kX4NV1csvmXAXYhcoJaHCk/hxG3/BL0ZnlGcY4v6gPMqMQwHoan9j8uuF0aoG2LnvIlifaD8ZmPpywTnd7gA9YMizIQEtxBS4vxykNkKCvU883irMKOB9dV4CqcJu0t/KKr/qHm6QIOsq5t7MsFtPyN1TDaw5X5r6LCarEK8kIHg+DxNLn2kDzWYsW8jj/N6DmLEc7e6+tyng7g95jFZwx1Jwj+GSWwT+qE2NbVf1ou9HqEUf3pT5tZesLZPTJLBFy1EX+hhH0W08s+ggjJtMcgKwimxpt0Y+3n5IVVwW4zSTB55uqAUC5FmGmxyZYbDD86iaIFzCYuJbKvFiiF6UTbxy2qULOtSm1zTMIbN1dtcBh4xIgf29P/EqtaLT/3raia80dYBf80uUFCD0xW8wP0yFLbJTa1suxawSLmlAob1j/TBXr2l9d4ek8JKBMVEFsfZ2X4LlrPS2r8rRyjLC4yhFDZ272qAjff3NG3Y8LreeDWltZ5Xe6Eqg26kvDmx2R0HSoRKmZmRWuOXDNampCJ0X4Pp8bs1agIIokGaSemseeFNsyixnRPd62meT+nxnjqrFJYgtBZSPqu4ei73/432KNSkuU4NxuOpKEH4E3btM3+t0yDYu57mChp8VGxl889hJLjFe8ttAWZMGIa6zC97n16s4ikwkb0ViZ8I6u8T2qTedJuRmd1fcTodffYAZ/U3ldXAsOINwGrjqj7FFv7ioJEkKh9+0WdG8cxHJG+2Dul8XoER+uHIoI8t4shpAiaeqGIfUPjejMz09YDXjkzdTWygQyOTYLTXYPdnGSeLh+GL7dX+9HzbbaH20PQ/7K8ikkNWSaiir9sCgEwMylMbYGikTkYDDwWVhX/8CNcm8W5lN7Bi5mejsu8Ifo7Jo+PnTMnbfGDunUIQm2/DcAR6EuQJcf6qzXTNa0ab5wFTEzPvP0WzLVyeimdJDYZkzE9liNxa2duSV66zZnjwsFPJq04cDt641QTN0WteCGtDEcGY6rXOHsVmje283wtSAKR6dFG0LbWEbL9njDbsBozCvrAe3TfNT4JBkCdaZEmFXoSb9ZOnOTUl6YD5ZZso2VHSGqhO4FDO/Q/tWVDhj5g1slhv51Y7203YNC9y+376ZupmpQ+4sYa+jpGymwUxKoOBro4IapLjDDnk3VCWNCjDcpaFPr9B2edbY8Ok2lflan8l1J+eOKq0sAwfWhwR5hBy5tKBPIQXI84KRk57VQyZ3bmcLfD1sBvN54Slr7gNQgTNoTPPziIo6BZ5K8U6EenLG1KAKzYopeicW8T5qUKykoJ2kcw362VrKQa0VN489K0g/wvzkyPL9E36gnS2WrDHgcMZZy7h5G2Ev8zYUe6uRuxHBbM8G83eaz0Y1IknTTS6s7oYGfjPMuy36h0tbqWmRD+0kNr4lbO3rlDclVmfl2O9Sc5tAZObnF/sMKk+2dmvSeet+QSv3oaRWFQ9mDr1bvr8BkXLkOs3NhxFidfbDO5akcrojn104CzxLhcbp6/so5/MRAPnTTtAi3uHOTcEqfNVKKTj2KCn0cMuCb2WOXYnDQdAW31XhEDqgpzfEsOorhSog75u7B28NYixTNNEmdd0R4MQOV5uudaYgTS4+L4rn5vK0t6Qc91ek7XWt81QAsbwCTDQybXa0BntXu2OK/2Z5nk+Viq+p9GthNjnGoaSNQt9HE0S4G4m8cmq7GLpX+VxGcR1c3NY0Fqq6NkcV7XJ3nnl9Oo8PN5zOfKytqWdbgBo5LJ0T+hVTWMRI1oUTvuUemwPl5KtJK8er1JKk8lszHM/5WnWXal7+bTYsgeeSsvQnEIveLKPYkD3FXhJK/v4kihY36di+xO+YyPH69Aaqj43xLRHgTI4at+NHa+xxK2dwF+phm4SRsaR57n3yyFf4yxOgibG4SwcF8wXKshPxJJDaj88OzaxvRuCs0heix0saX0T0fsikNFDMWIKl2VrYby5xBuRjsNJP+7IhOYW+Dt6AucMRRp/y0lwzH5tYxee3wXAI4yJwGPVDCybInvgItwgwMFaiSDntVlAYOFZJnBdA0VDTmt9dxJc6tyuqkXfM94IlTNDurg6YuxMOKaoDQAPL9S7KJ4b6tzhaF6ygPZgxTIo+wxjGFC2sTRFHFJGE4QdhouQ7xuuQ4Ys37gVix/NDt/dbBxYnfWY5DfJsXsv0e37oQHHtqYwCtnOgDS28weTsjymvONYQXw3mf6tm9b8gbS/V9z6XCZ/sFaF0FoIoEpq9g4s+8mGHlYwj3l12Ak60veQ84hNO3/URhIIVKE8Cgb6O5nuw3wRhGtywcAESgMujUf5pDd1UXnw6Al7mj9LXLIIV5mEUIMq5aokl4v47yBnS/5Lp6FbQ+XXHB0nI7Os+Br/h7eVqTVpGBFumV3KniT8OGcFnbi6HwRQTnQ4RuaDQkcCFbFerUqyPfZqIKEeBeisixcRZzizo32KrWpzpkuJ7hi/LKXul3U82Cb8efrHxuH8aHapIJAu/jfvm8M87O2Oe9QzbJ3/FGJeoE3u9z7dHnWxQKs7mkiJxuCtDe7FXLrnviMI4LWPSSl7yQZPPvjpZwIcYBdS6vCvMTY3xRdTsUK3jrFVz5Bo98I0iNoYmEaZzeoXeSnRkFhg7Tu2JcsnEV6AKX28CqZUbOc+5ysSx4V+YVY+k4UpbhjOfz9mi6uR1mRGuPxDBukapueyj+JTdMSdmhcY1tEvjYQH862RpHOE0LvWKcpXWAjNuI2j3Ss02ulMXSItZNh2YOqwD625jxphyvTj3+HmohcSuWwnKYN052pAshAy2n9exM4hGJSeDSvmy0e+/CEFMq30yCB1ehL+CxOOQj2nLU4AjR9jXEowAIrzmvo6L3yRE0rdx3AV7YomXImhjQKH1mzFpVRILH+ExtQqSKPD0ndWajZ0fru2ovtsaX2N6LB3k5stWdX7vxDMa8u6wQWJaJibTnjm+ziOaIEpOTdIxoszuj/fkaVJ0rFflvkf8dEZDlrMgOf6SavB3ynyNUyXtr96J8OzERm+mQwUR9ox9Gc4KwzOx+lWnxP1MSxVWxpWrO06VVDilYGrO50vPHkGXeUv7G5oGfhuTRiCrNU7OTZUqXsgVJcGlT7vH0yowDnuvQyl2l0G3yS9Bepxs6mtJhsn+KCDV+WfGfeCExMXjPV0XdvfGXGiJ2w9/L5C8RAetoGmPgdlZM1gEnJFpDPHiaz+G2iryIGtz4cphrfYrjNXvCwDwOnotQZI0kZoMooXKqq+lpRZhmzs/UqKQwPtgxpKefm16lY8/ILbffVsDWWIFEeGXW08AS1paWOQ3iMZlaSK7YjWWeY9/aK14PZGFL6YvK91DJiguFHj+aPFbXgh13O6qOjlym/WZzzGM4dx056VAI8je3gqGvJlQvvR9JI2qFY5VIwXXlIKXHpV8UejkESi5z60qH4nunOxnl3H1nrxJ+pLqkCGt4Di1LvGZDuA1EueCfte/IU1iIMAbZXhvj87w3NpGuzaNX/ZpgQggQUP+1TMpZGFeM3XUTUPW5r+lxw8wCE/AbLkRQE5T3l2FxD7ZnnQ3DImUVbipYpgeg/Ou+tg9CUzWTHlCxvFcMxFb8vLDPPipt4lYAtMyuUfmvID/jON8lB+nzgFiZ7JhGRZjwoJb0D+w6g7C72ZOYjKLV8ItSTYbU1sv73XpPIshXwY7bBg+mtf9OS6q7rc7z9iI8Czb4PYKkkaHWhVPCoS3dEkteC1GL3WV01dhUWBwijimBUMON6BtVzjblL3Mnhdv7OC+VI7PLFkVyKpCWe5sIuNY0PWGEytDLsSQmRFQ1Z2y6AeSLXAN+4rALAWJJ8BIf1t5oXRFJACia9VdSoWhuK4lCFToPTDO4IbnSFl+WE0ggS9iJBCfCOqqNRJfm7uMrTH/hLj/lbP+tvrnOgInaGUnHzGDhjJaZIgG+z5hX6qf1gr3eUQikn2IprojEzllcZazDEMZ6/TO8TM1d4SFq5fijqvbL/t95ihOAVZ7O2qzxQnzSHd4Z6uBjgBzmbj9OBZiLIaMueictxKcsZe3qtMu/ct5j9x92jq8rVzJtJx+JQguncVPPpW8KQXamj5CB3oYWMSBZch/PlNaE0KHOmV8iDtQ3X4l+YvlkMptJRpUTzV59tGKus8mP0YibzfgB3IgoskG9gqp7I5ZtHeLon08riaS+BndygQQ6GovxBtNiXZA5d74IRiaYtIBQkcLeaZx2DPkQMRkt9Dq0715mHpvo3jJsrww8QcR7cYhlFvntsHJ7hKQkeJy6gIMdxp+jrL7dNSkXk4pI+vbgC87+kGAtwkp41X+mhv8MiZMoba5bHKo4LmDPZVCxqf1mlEQ1lJSNWABPR3TIySkSNjKcjVB9BtTMMKBIEb/24xCjxb+LIRWnEAdYZiThjzwxa69aG6+AIy7ZkuQDQOqMLJi9fHDap8vv44BEGW0Mmt0sBYW2Eqg2qW2OhClLicawzsFjM12Fw7d2LgcYV+0r1NUHXbxn1nVL+ZD3EgvkYQRHCgR7esMteXWXCCi3QrfZl9SbnIk5Zx+lix1j4nChWpPO5dh4z+lfbpMJIGYpcUl6kfU/TshssFxqU6uAeHCA6Vvp8CfwI+j3/YM1Dnx2O3aSyFPbyuGjaY0P2miS5hYo92LgayDwy+fc2X+uwb9G1BOftZWbGvmUlUWUJPrxchtKLOON03wXkmxHRrQF4A3lbps/5tdz2MmV5P8WLFDwJfbNGQyh4gYQ59JRqPfWH8NiQA5vzr6L2e8hB3rHGSN2AudWmsKYJjkDjwOUbv7JWtyaREK3s/HJej2+qL2Gau2JsIJtSUSMCditmB24fnuUimHkod9uizFkZhj+ORvFEPcYpRLPhP17X3Xhsg+xAmETl3ZWvvYNXnlhxHbgMiq6NPq3S49a+DkgeBtc3N4k76AmCleNe9+kNAu+th4xdeHpkGQRe57aTveYhjmz3/8b4i2EBxSGAAA',
            'Content-Type': 'application/json; charset=UTF-8',
            'Content-Length': '150',
            'Host': 'mobile-api.hopper.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/4.9.0'
        },
        body: JSON.stringify({ "userId": userId, "deviceId": deviceId, "firstName": firstName, "surname": surName, "email": email })
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

const compressToGzip = (data) => new Promise((resolve, reject) => {
    fetch('https://services.multiutil.com/api/tools/compress', {
        method: 'POST',
        headers: {
            'authority': 'services.multiutil.com',
            'accept': 'application/json',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/json',
            'origin': 'https://www.multiutil.com',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36'
        },
        body: JSON.stringify({ "sourceType": "gzip", "destinationType": "gzip", "data": JSON.stringify(data) })
    })
        .then(res => res.json())
        .then(res => {
            resolve(res)
        })
        .catch(err => reject(err));
});

function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }


(async () => {

    let i = 0;

    console.log('')
    const otpProvider = ['SMSHUB.org', 'SMS-Activate.ru'];
    for (let index = 0; index < otpProvider.length; index++) {
        console.log(`${index + 1}. ${otpProvider[index]}`)
    }
    console.log('')
    const otpProviderChoices = readlineSync.question('Pilih OTP Provider > ');
    const refferal = readlineSync.question('Masukan refferal ex. 81RVS8PZ : ');
    const piro = readlineSync.question('Mau berapa reff ? ');

    const APIKEY = otpProviderChoices == '1' ? process.env.SMSHUBS_API_KEY : process.env.SMS_ACTIVATE_TOKEN;
    const sms = new SMSActivate(APIKEY, otpProviderChoices == '1' ? 'smshub' : 'smsactivate');

    for (let index = 0; index < parseInt(piro); index++) {
        const balance = await sms.getBalance();
        if (balance > 1) {
            console.log('')

            const refferalLink = `https://go.hopper.com/to/friends?referralCode=${refferal}&install=true&pid=referral`;
            const userId = uuidv4();

            const refferalId = await getRefferalId(refferalLink);
            const detailRefferal = await getDetailReff(userId, refferalId);
            const name = fakeName().name.replace("'", '');
            const firstName = fakeName().firstName.replace("'", '');
            const lastName = fakeName().lastName.replace("'", '');
            const email = `${name}@gmail.com`;
            const deviceId = '6cffd98191d' + await randstr(5);

            await trackingDelivery(userId, 'https://mobile-api.hopper.com' + detailRefferal.funnel.link.url);

            console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                        `Mendaftarkan dengan nama ${firstName}`,
                        colors.Reset);

            let data
            try {
                data = await sms.getNumber('ot', 6);
            } catch(err) {
                console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                    `Gagal mendapatkan nomor. ${err}`,
                    colors.Reset);
                await sleep(5000)
                continue;
            }

            let {id, number} = data

            await sms.setStatus(id, 1)
            const phoneNumber = number;
            const registerUserIdResult = await registerUserId(userId, phoneNumber, deviceId);
            if (registerUserIdResult.AppResponse == 'Ok') {
                if (registerUserIdResult.response.SignUpResponse == 'NewUser') {
                    let otpCode1;
                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                        `Mencoba mengambil otp dari nomer ${phoneNumber}`,
                        colors.Reset);

                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgYellow,
                        `Menunggu Kode OTP!`,
                        colors.Reset);



                    myCache.set('dateStartedOtpCode1', moment().format());
                    myCache.set('dateEndOtpCode1', moment(myCache.get('dateStartedOtpCode1')).add(parseInt(process.env.TIME_DEFAULT_SENDOTP), 'seconds').format());
                    let repeatCountGetOtp = 0;
                    do {
                        if (myCache.get('dateStartedOtpCode1') > myCache.get('dateEndOtpCode1')) {
                            if (repeatCountGetOtp <= 4) {
                                repeatCountGetOtp++;
                                myCache.del('dateStartedOtpCode1');
                                myCache.del('dateEndOtpCode1');
                                console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgYellow,
                                    `Mencoba mengirim OTP kembali.`,
                                    colors.Reset);
                                const registerUserIdResult = await registerUserId(userId, phoneNumber, deviceId);
                                if (registerUserIdResult.AppResponse == 'Ok') {
                                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                                        `Otp Terkirim!`,
                                        colors.Reset);
                                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgYellow,
                                        `Menunggu Kode OTP!`,
                                        colors.Reset);

                                } else {

                                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgYellow,
                                        `Gagal mengirim OTP`,
                                        colors.Reset);
                                    otpCode1 = 'failedSend';
                                }

                                myCache.set('dateStartedOtpCode1', moment().format());
                                myCache.set('dateEndOtpCode1', moment(myCache.get('dateStartedOtpCode1')).add(parseInt(process.env.TIME_DEFAULT_SENDOTP), 'seconds').format());
                            } else {
                                myCache.del('dateStartedOtpCode1');
                                myCache.del('dateEndOtpCode1');
                                otpCode1 = 'repeatMax';
                            }

                        } else {
                            myCache.del('dateStartedOtpCode1');
                            myCache.set('dateStartedOtpCode1', moment().format());
                            try {
                                otpCode1 = await sms.getCode(id);
                                if (otpCode1) {
                                    myCache.del('dateStartedOtpCode1');
                                    myCache.del('dateEndOtpCode1');
                                }
                            } catch (e) {
                                otpCode1 = 'failedSend';
                            }
                        }
                    } while (!otpCode1);

                    if (otpCode1 == 'failedSend') {

                        console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                            `Cancel order number, mencoba daftar menggunakan nomer lain.`,
                            colors.Reset);
                        try {
                            await sms.setStatus(id, 8)
                        } catch (error) {
                            continue;
                        }
                        continue;
                    }

                    if (otpCode1 == 'repeatMax') {
                        console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                            `Cancel order number, mencoba daftar menggunakan nomer lain.`,
                            colors.Reset);
                        try {
                            await sms.setStatus(id, 8)
                        } catch (error) {
                            continue;
                        }
                        continue;
                    }

                    if (otpCode1) {

                        const linkVeryfId = otpCode1.split('/')[otpCode1.split('/').length - 1];
                        console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                            `Success dapetin token ${linkVeryfId}`,
                            colors.Reset);
                        const resultToken = await getTokenVeryfLink(userId, linkVeryfId);
                        if (resultToken.AppResponse == 'Ok') {
                            const token = resultToken.response.appTarget.funnel.token;
                            const veryfTokenResult = await veryfToken(userId, deviceId, token);
                            if (veryfTokenResult.AppResponse == 'Ok') {
                                console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                                    `Success verified token.`,
                                    colors.Reset);
                                const resultRegistration = await finalRegistration(userId, deviceId, firstName, lastName, email);

                                if (resultRegistration.response.FinalizeSignUpResponse === "Finalized") {
                                    const dataXRequest = {"identity":{"userId":userId,"authToken":resultRegistration.response.authenticationTokens.accessToken,"deviceId":deviceId,"appId":"com.hopper.mountainview.play","version":{"value":"5.7.2","buildNumber":116827}},"preferences":{"locale":"en_US","currency":"USD","timeZone":"America/New_York"},"savedItems":[{"savedItem":"Carriers","state":{"tag":{"timestamp":"2022-04-08T13:11:03.165-04:00"},"SavedItemState":"MostRecent"}},{"savedItem":"Regions","state":{"tag":{"timestamp":"2022-04-01T12:48:02.318-04:00"},"SavedItemState":"MostRecent"}},{"savedItem":"DefaultLinks","state":{"tag":{"timestamp":"2021-08-19T20:00:00.000-04:00"},"SavedItemState":"MostRecent"}}],"experiments":"H4sIAAAAAAAAAJVb25bqNhL9F55n1upLTjInb9yble6GAZrOq7AFKG1bHkmmm2Tl36dKkm1JluHkYS4HhFQqVe3adem/BmeSVXTw61+DJ65o9roeDyvFc6IYLwa/DoZnwjKyz+jgX4PNiZdbQc40K7lQ8OWYF0rwDL56nW+GJUlGghQpTWdEUO/rMRES/pPOKwIrFKXBzvj9MCcpreQrVWuiqAzP/mDlStCUJSjYK1fswJJayPYgfQe5EiyhG1pIptiZqcuWShUsK0sqViz5kMPsk1zksCwz2A/OwkW0UIcqw18QIbgaE3mCHz3z9MiK42rGi98qCTqiIhBy9PNLlSm24ZVIYGVwZE43iaC00NJNBC+fKNwY92g+2d3DyjU9M/o5oQo2lmN+ZuksY8eTGp9IcaQjUhSdgxeFrECxCX0hWcrOVE6LtOSswFvX//cO99YnzUCKP6kWdXk46M1QTlZUvJLPlIgChL+D1UMmdpylY9w5y7S21zQHFb8tAgGcfY3gIKyawt0vERt6K+DxDiz4plVQoxd9eX29BJ4E79U+yBiNQYW7k72gaH0jIpnckYylMUOuX7JW+7BIBdzTe68JJRl+twF9JCcjmLcAbwL/kjzTv4zs/yap/ZRlYIVjkpx8t9ie6J7K1q1mlQyE3TGhKpItwCZFxgrrK1YF8Dz3d7B6wmTCq0Ld37Vnj5i53pYcdw+w5pUPC2a8+p2p05jnJVVMcfFK8toDwb9KwtJFcQZtc/10gWftaSr1kY5r8yLlYlOiJuBJnpkEQzqy5UbbNUdrsfaLZkIuOewNCHNalorl7E8t0TC9BMq1t0CvH59o8sErtVG0lN4isCPYHLSAmpEb9RtTSsI/tVFbn3efBT9qnh5Ni4o5GKvgPPefpbtuVKWkDFHErjHusaHZYUPFOQJt9rmmFZgTNQj1wlOa3f9093BbRP2MStuHeWtcmno7u/ZsnPD+7vdVsHWNWUt1omJN/1d1FYQuKK0zaOcdgXpCEQHqX0hZwnloSC9EfFB8cfsM4e3H5tYzJqQacf6B+jIIGyIIbxbM2BdNd3KYoOkHy95JlhOhxlxADII4sWIZV1takCL6NqgS+J8pWGRB38rURpZ23YoKyQuSaZsZZhloPa0SZWXUzxRIsAZbpE+ggYt2LPgv9ynM88avOKEZhBr93Rde7YUCskDAZNIEiyU5LovsgtIfiKgdGUOq1lqJDrkjghEL5t1nX4Mph5EzEnhMDJlnfE+yUXVxI9DwE9ATvEnirTTEPnOC59eRIgTz5+qg4BKSREK6FXArGByZHkPjAJOZ2ahljaiLONYa24CtQ0/7T1hnLKzGa9g0rv1lQRFCNuxYvJU+hOl76gvGf2rvgdq1pj/9gvMZYpk2Agc7Gn5kjVlDd6Ht2OdDlu/Ubt4LG7g2olu7vWZCcXEXecmlZPvsMiNSvcAdyRjDxKJAkPa9oDWhLfmg/NyRB4HpnX6Bl4YXsWKOSPKBfOF+BkQBGVyPm8NyqjkcREfheUAbheOxdHviglfHk4nIMy5ABRICgHG5ZaExZkWOfoxFWtrwhxqxo6KhNb+QVPSJoJ0LhFx3QQTV17JTEC2hqXGsdlEUuWKYhfx7H/y46+pNvFnTQ1V0RYaoXKBfpfwTBVoBbqiQjGkKWBtgs6FL93bmQZ7gcalAYiUtQs0y+sUMr6k9r8OOZuuHn27cAr4DWwtZj4davsIabugvBgvYsXJTleh5CJUNjlkeAAxZAW4+gW92zHYOZlWkcaMwxmVNE4Gsodqh9XxyDT6GiwR0KEYwwU/kaUMy2uJX6OYQBfABYFf4RscijfuGTkm4MN60k9xsqMIz5ZpqGKp8VI0wjE1ByoZgxHwbBIDNKFEdEBsjVMxpwSq5eV6MQI3ZFffrxWawYSoEyaTG9hxoaJPoAOHg70QBdZb6LRx8WuAhEK3hKiYgmMdyyHuj49s0a83ZXoPbtKgJll0xuRQkZwk6U4VGPsGIP2N/MLgO5o4/8ti1a5uvfGTePfZiv75Ql+PH/Lo9a6rYiaQ3heuQ8wYAFscCfjH9SnTCiRb4zgBOPq8jv5taWtrkpc8gqWIkq7cNywdzg7vIKYEnKWI+tblRIfdcdP0+gifNiasKQ4vsuClYMcTwd7rHJHsF6Q5+0glqcsO+lAuENje6FfxQrxDTwMIfmqQKhENQsLGu60NbkFyaoNYk944DwbYNsjkk2blfn5m9EnQ6c4u+cG9IIMLimCJTCdRljANtx9LAJouMR2tLaqyMMkp+Is7XJJf9V3cNF6R/+ObVBX4H4822XO8TTeMNhrqiRrPHH8xju4Y3/YLnZZLuwnSpL5BF6zjRZHGjyOUVD46ECCvIK0RqjAaFIomyCnuhRdVDZGwNpyY0qNeO3KFh1H47BR3YwB9SOy+VYqKGrCCX8pYZL59+QfgpOXiaqR3q6s0Y1vv2EIpkr+MmtDLmDpFn0oeDzRgq+kPmucq6zun7m4kcM3LmgMmdCqYOl+v/9PF99VlrGJ0n8ts6XwBj0FAcedjdYtWaW5/HO6DsXwVskn+97MK6QXPHhAEWisswheir6pw1LL1aVSyLPSciNWuC/D2jyhY3Eez1S8jARsyqgVeo1fS+8fjbZVqPZB6YMLA1zeHg22zAAtgEdtXFoZYU2BLWHGwV4ut0T4ovCMNjnvF8z0gH3LVpTwTrZlRB0jAWF2Co2QhuPj7h9cESxC3DnBL/mePFuCsxf3wCjmmw8f7RRi6QKWdVfj3ruB5VbLFiVmXZBFioZOqVr2lKaV4b82huDDmSTLUxztQFyoy0he26BAI6BG7wqTOY0gCWZvFOMhI6ELJ3/RxRz7RVxlnWca4mu1BgQYmpqhrObatL66rfjAobkZy6HbJgrb1urGjTrPpiKx2AbmSR+mtAfi6CB+nNtcMwD0dOBPkET9w94D1iHBa52KZkgG2vk3FEhUCrDIuJUwNgdVw6Vh4tji2K7Ym+0s/wifzU2Ood1nz/jqFAzqgjBNZnYpxaTmha6TaPbmRUnaygLjqb4o1UEyZAffFFXlKgrwbrEp6XD9+dnSBy433Q2YwtLxJwzVCrn7ruGgssxk9Bn9oGZwDRGhNgr8e7WaUqAVQbXs4GWmlfEnRQm1tblXVAAl2+QXPj+7/0+f6MZXDmskL5BeNKdSAHFOumWR6pn8E778Got7ytmgb0DF796bIH8u94+HI4L7NKfhtcqV4OeoqWNSOiX2pZ0Hdy8bVm380or9lA3kqbWOCG6As7ICyChZZa0/zlYU0TSFrqqB6ua3T2TBTJEbas5LeDU5NSeIFp3NaMnTqIjo4INhCkhsVlTQmQL5cKYhqEkuYQ1UyzrC7VRtulNfiGbVNM3FemSFCb48Ndx12cEAE/WAMacWtrcZqmi70TKtmxuB+ERdGeWm2rhqZo8uBcmBQfw+zIbR095nRoOuvtFbMJfQ4iz6c6Xa1hjCNSPbZHopXt9EOk+rIdeDZuZMNip+KjNfffCgQe0QO3dt2ouS8g6GKwuCyBmoD7BWWbSp2AxZr23LKYgSxwcQyOcXAPakFNkWz1DAsxN8P3xS60DJliWws5EKl6eSO+mXYtByYIfPbvHD/899lRpnP7Zyx8swKgpw0Znff+ZzDhNf1M7dUbmHAcMtr5u9phiBYX7xAHg0YwkqMehoCtXR0EBOzo1Vf7KhehYDYWDHM0kNq89MACRKOFXhXjB32VitjaPnuBBCliWU+QcPyJO9oSTFjQkW4DKaJWLFYD3dzk/IPGnQdv13pHTGLj5K98ARb69QN1qNKZP4Hlj3d3b5tJT05aF9qq5NS0oOpUyAKV0++bCwRZiiyq21NzOVBIL8MuZROCgiNj6dQ0L9UlRkA856jZ95b1kSu9fAoHA5UGzSwLjKSYKuh+QkZ/7lFnW4lrffqKSf8gPG1+f5peq2L4/aJYNzioJ7ZWfzuMD4889RNG72yvKxE72iR7dQELO6kfh0qoKwMQNT0wDTQAc8PuupMVTnfHTlRRoVlsDEZ1bsXwEb+BiQODlLquojEwcu1ldslLRmh1K7l9f/DHMq52WEKC1rWhVSVP9QzEb8v9H4bae3RVQ+oWaA7t9AZ11xgTfbd64rcwTFHNli66rcURP3IV65KD7uJB9SVJhhqPnJ4HOR8ff0k5cncZiTGgnqgXbwBZUjNANmGHA7AXyKrDAp5Pr/x6yyBoQWDvHqKMO8VzQ/+e3/qhXTNuUBFgNLBhKmIdVn4Ew5IgyRouD8nELevB4mZQQLldXY0HZy+wDdwCdET9t+SCZIaUkenICDppAA/JU2ToQ5MQXRHBAKe6w46mPw4Y5Y7hBJesXaOORvEJoUDUuN3qKTynThxt+QwL9UmFSZ1f2FF0TaiPT8QTZR3h0XC8r1vd6KqK20n9Fk9sOmb/tNIfbVlOY5nNGOInnCDmFUstcwOTEsBk0aCcF8OyQl/moWEALGhNJUCQb/pIunY4o2uq0G6IGF2euRxC0gHKzY3d3iiFwgFUnLWu8TIZYXmbSpslO4dqILPVzdexhZ9WrBEYh/5VM9P7sltFy0ZehMQz4h03G1riJG047HzUTaC7PR69b2s5jWfF7dbTU84K8NZ6vMa5jo+kwRZ1yzIsojuVvQ4tqz1vth1fd76+8E3OdHziILuvVCfn7vEarIhuqjwn4lIL0aJctw14e67alDZJSv5JCRpS4+gwb3fqqjdeOXg+JpD+mBS6c9+d2PP4dGsL0nWYcSd3Yy7rzc5cb8i7nXEmMRmz3/nu0p2/1pVys6Zn7tram+2zolt3WoSbT1bSLQd03DFpETnmp/iYaBDLSkm4065nhCEg8AF1/6Gm6hVjiATMyQlR14eLtll2m2aj7/NTpzGMul2z5IRzroxi/V8P+OJq4M7xIbgu5PjvbFpD0syZTt+w5mnbA+iZI0FYgc3+KDJbb51UTSR8vJsAL3JqaBRhHz5bYUMF1hiP2J6YSG/Fifn+fCVOgBXpMVPrZsM01fv/w0nSoa7pxydJm9O0PFjmgnwSHUHjVojDLWKPqqK4mLEitJUSRX8rMg5oCi4BJ+gkoxmjj3Ls+lna2tIUpEGC+xWJA8PVQo/0eiMRENExxtvuTXNF0xH6wVxzOJr34ldsgDtk3N01vaU49+8DerrwMZ5gl7htccPNcdo1ZWTgDGo9c/jFnHTIvP6TDRMeNZsygWPwq/vFCxgFOdJnyBxMluhER/DrrErp7PsMnrvvryIcRF+sev8a5xlgqTgqYDr9HPPK/KqeRPKVF+YFpiNfQ5GtZASZgyldXLlJfJAKzSv6VjjGrH3QFGPcFhNuXB1BGfcP8BMbWrEebhwozqy6ZhXIV9d04u2J2CSlt/8Cbo/Ow4RbpHvl3qV0dckbDegbCKj5PoSTRNeLu8zUDpNpnuWOk10Z2fvhMR89MnNzyCxWXh00ddXHCHUJErPa7h5rFmAqoPHRkb6BlRSDZluONtiIkEVfSHLq/q1GQ/bRkGVPhTdO7/zqy99//x+dxK8hVjgAAA\u003d\u003d"}
                                    const gzipResult = await zlib.gzipSync(JSON.stringify(dataXRequest)).toString('base64')
                                    await trackingDelivery(userId, 'https://mobile-api.hopper.com/api/v2/friends',gzipResult, 'home_screen_banner');
                                    const resultTrack = await trackingDelivery(userId, 'https://mobile-api.hopper.com' + detailRefferal.funnel.link.url, gzipResult);

                                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgGreen,
                                    `Success ngeref, kode reff new account : ${resultTrack.response.screens[0].content.sections[0].content[0].component.content[1].content}`,
                                    colors.Reset);
                                    await sleep(5000)
                                } else {
                                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                                    `Gagal ngeref, kode otp tidak terima atau tidak terverifikasi oleh hopper. | ${resultRegistration.response.FinalizeSignUpResponse}`,
                                    colors.Reset);

                                    continue;
                                }
                            } else {
                                console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                                    `ada masalah saat verifyng token.`,
                                    colors.Reset);
                            }
                        } else {
                            console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                                `ada masalah saat get token.`,
                                colors.Reset);
                        }
                    }
                } else {
                    console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                        `Cancel order number, nomer sudah terdaftar.`,
                        colors.Reset);
                    try {
                        await sms.setStatus(id, 8)
                    } catch (error) {
                        continue;
                    }
                    continue;
                }

            } else {
                console.log(`[ ${moment().format("HH:mm:ss")} ] `, colors.FgRed,
                    `failed send otp.`,
                    colors.Reset);
            }

        } else {
            console.log('You don\'t have enough money');
        }

    }



})();